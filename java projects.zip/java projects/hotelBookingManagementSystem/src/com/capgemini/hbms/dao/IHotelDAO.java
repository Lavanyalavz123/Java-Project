package com.capgemini.hbms.dao;

import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;

import com.capgemini.hbms.bean.BookingDetailsBean;
import com.capgemini.hbms.bean.FilterBean;
import com.capgemini.hbms.bean.HotelBean;
import com.capgemini.hbms.bean.RoomDetailsBean;
import com.capgemini.hbms.bean.UsersBean;
import com.capgemini.hbms.exception.HotelBookingException;

public interface IHotelDAO {
	
	public abstract int registerUser(UsersBean usersBean) throws HotelBookingException ;
	
	public abstract int loginValidation(int id,String password) throws HotelBookingException ;
	
	public abstract int addHotel(HotelBean hotelBean) throws HotelBookingException ;
	public abstract int deleteHotel(int id) throws HotelBookingException ;
	public abstract int modifyHotel(HotelBean hotelBean) throws HotelBookingException ;
	//view specific hotel details for modification
		public abstract ArrayList<HotelBean> viewHotel(int hotelId) throws HotelBookingException ;
	
	
	
	public abstract int addRoom(RoomDetailsBean roomDetailsBean) throws HotelBookingException ;
	public abstract int deleteRoom(RoomDetailsBean roomDetailsBean) throws HotelBookingException ;
	public abstract int modifyRoom(RoomDetailsBean roomDetailsBean) throws HotelBookingException ;
	
	public abstract int adminLogin(UsersBean usersBean) throws HotelBookingException ;
	
	
	
	//view Destination city to search hotels
	public abstract ArrayList<String> viewHotelCity() throws HotelBookingException ;
	//view available hotels in particular city
	public abstract ArrayList<HotelBean> viewHotels(String city) throws HotelBookingException;
	
	//filter hotels
	public abstract ArrayList<FilterBean> filterHotel(String checkin,String checkout) throws HotelBookingException;
	
	//book hotel
	public abstract int bookHotel(BookingDetailsBean bookingDetailsBean) throws HotelBookingException;
	
	
	//view booking status
		public abstract ArrayList<BookingDetailsBean> viewBookStatus(int uid) throws HotelBookingException;

}
