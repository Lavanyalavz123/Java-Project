package com.capgemini.hbms.dao;

import java.sql.Date;
import java.sql.Statement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.util.ArrayList;

import com.capgemini.hbms.bean.BookingDetailsBean;
import com.capgemini.hbms.bean.FilterBean;
import com.capgemini.hbms.bean.HotelBean;
import com.capgemini.hbms.bean.RoomDetailsBean;
import com.capgemini.hbms.bean.UsersBean;
import com.capgemini.hbms.exception.HotelBookingException;

;
public class HotelDAOImpl implements IHotelDAO {
	Connection connection = null;
	HotelBean hotelBean = new HotelBean();
	BookingDetailsBean bookingDetailsBean = new BookingDetailsBean();
	RoomDetailsBean roomDetailsBean = new RoomDetailsBean();

	// PreparedStatement preparedStatement=null;

	/*****************************************************************************************************
	 * 
	 * Hotel Methods
	 * 
	 *****************************************************************************************************/

	@Override
	public int addHotel(HotelBean hotelBean) throws HotelBookingException {

		int hotelStatus = 0;
		try {
			connection = DBUtil.getConnection();

			PreparedStatement preparedStatement = connection
					.prepareStatement(IQueryMapper.HOTEL_INSERT_QUERY);
			preparedStatement.setString(1, hotelBean.getCity());
			preparedStatement.setString(2, hotelBean.getHotelName());
			preparedStatement.setString(3, hotelBean.getAddress());
			preparedStatement.setString(4, hotelBean.getDescription());
			preparedStatement.setDouble(5, hotelBean.getAvgRatePerNight());
			preparedStatement.setString(6, hotelBean.getPhoneNo1());
			preparedStatement.setString(7, hotelBean.getPhoneNo2());
			preparedStatement.setInt(8, hotelBean.getRating());
			preparedStatement.setString(9, hotelBean.getEmail());
			preparedStatement.setString(10, hotelBean.getFax());

			hotelStatus = preparedStatement.executeUpdate();

			preparedStatement = connection
					.prepareStatement(IQueryMapper.HOTEL_ID_QUERY_SEQUENCE);
			ResultSet resultSet = preparedStatement.executeQuery();

			if (resultSet.next()) {
				int id = resultSet.getInt(1);
				hotelBean.setHotelId(id);
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return hotelStatus;
	}
//delete hotel
	@Override
	public int deleteHotel(int id) throws HotelBookingException {
		int hotelDeleteStatus=0;
		try {
			connection = DBUtil.getConnection();
			
			PreparedStatement preparedStatement = connection
					.prepareStatement(IQueryMapper.HOTEL_DELETE_QUERY);
			preparedStatement.setInt(1, id);
			
			hotelDeleteStatus = preparedStatement.executeUpdate();

			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return hotelDeleteStatus;
	}

	@Override
	public int modifyHotel(HotelBean hotelBean) throws HotelBookingException {
		// TODO Auto-generated method stub
		return 0;
	}
	//view specific hotel details for modification
	@Override
	public ArrayList<HotelBean> viewHotel(int hotelId)
			throws HotelBookingException {
		ArrayList<HotelBean> hotelList = new ArrayList();
		
			try {
				connection = DBUtil.getConnection();

				PreparedStatement preparedStatement = connection
						.prepareStatement(IQueryMapper.VIEW_HOTEL);
				preparedStatement.setInt(1, hotelId);

				ResultSet resultSet = preparedStatement.executeQuery();

				while (resultSet.next()) {

					HotelBean hotelBean = new HotelBean(resultSet.getString(2),
							resultSet.getString(3), resultSet.getString(4),
							resultSet.getString(5), resultSet.getDouble(6),
							resultSet.getString(7), resultSet.getString(8),
							resultSet.getInt(9), resultSet.getString(10),
							resultSet.getString(11));

					hotelList.add(hotelBean);

			
				}
			
			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		return hotelList;
	}
	/*******************************************************************************************************************
	 * 
	 * room methods
	 * 
	 ********************************************************************************************************************/
	@Override
	public int addRoom(RoomDetailsBean roomDetailsBean)
			throws HotelBookingException {

		int roomStatus = 0;
		try {
			connection = DBUtil.getConnection();

			PreparedStatement preparedStatement = connection
					.prepareStatement(IQueryMapper.ROOM_INSERT_QUERY);
			preparedStatement.setInt(1, roomDetailsBean.getHotelId());
			preparedStatement.setString(2, roomDetailsBean.getRoomNo());
			preparedStatement.setString(3, roomDetailsBean.getRoomType());
			preparedStatement.setDouble(4, roomDetailsBean.getPerNightRate());
			preparedStatement.setString(5, roomDetailsBean.getAvailability());

			roomStatus = preparedStatement.executeUpdate();

			preparedStatement = connection
					.prepareStatement(IQueryMapper.ROOM_ID_QUERY_SEQUENCE);
			ResultSet resultSet = preparedStatement.executeQuery();

			if (resultSet.next()) {
				int id = resultSet.getInt(1);

				roomDetailsBean.setRoomId(id);
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return roomStatus;
	}
//delete room
	@Override
	public int deleteRoom(RoomDetailsBean roomDetailsBean)
			throws HotelBookingException {
		int DeleteStatus =0;
		try {
			connection = DBUtil.getConnection();
			
			PreparedStatement preparedStatement = connection
					.prepareStatement(IQueryMapper.ROOM_DELETE_QUERY);
			preparedStatement.setInt(1, roomDetailsBean.getHotelId());
			preparedStatement.setInt(2, roomDetailsBean.getRoomId());
			DeleteStatus = preparedStatement.executeUpdate();
			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return DeleteStatus;
	}

	@Override
	public int modifyRoom(RoomDetailsBean roomDetailsBean)
			throws HotelBookingException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int adminLogin(UsersBean usersBean) throws HotelBookingException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int registerUser(UsersBean usersBean) throws HotelBookingException {
		int storedStatus = 0;
		try {
			connection = DBUtil.getConnection();
			PreparedStatement preparedStatement = connection
					.prepareStatement(IQueryMapper.USER_INSERT_QUERY);
			preparedStatement.setString(1, usersBean.getPassword());
			preparedStatement.setString(2, usersBean.getRole());
			preparedStatement.setString(3, usersBean.getUserName());
			preparedStatement.setString(4, usersBean.getMobileNo());
			preparedStatement.setString(5, usersBean.getAddress());
			preparedStatement.setString(6, usersBean.getEmail());

			storedStatus = preparedStatement.executeUpdate();

			preparedStatement = connection
					.prepareStatement(IQueryMapper.USER_ID_QUERY_SEQUENCE);
			ResultSet resultSet = preparedStatement.executeQuery();

			if (resultSet.next()) {
				int id = resultSet.getInt(1);
				usersBean.setUserId(id);
			}

		} catch (Exception e) {
			// System.out.println("database");
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return storedStatus;
	}

	@Override
	public int loginValidation(int id, String password)
			throws HotelBookingException {

		// System.out.println("Inside Login Validation");

		try {
			connection = DBUtil.getConnection();

			PreparedStatement preparedStatement = connection
					.prepareStatement(IQueryMapper.PASSWORD_VALIDATE_QUERY);
			preparedStatement.setInt(1, id);

			// System.out.println("Prepared Stmt Done");

			ResultSet resultSet = preparedStatement.executeQuery();

			// System.out.println("Query executed");

			while (resultSet.next()) {
				String validPassword = resultSet.getString(1);
				if (validPassword.equals(password)) {
					// System.out.println("Correct Inputs");
					return 1;
				}
			}

		} catch (Exception e) {
			// throw new HotelBookingException("dao null");
			e.printStackTrace();
		}

		return 0;
	}

	/************************************************************************************************
	 * Search Hotel Methods
	 * 
	 **************************************************************************************************/
	@Override
	// view Destination city to search hotels
	public ArrayList<String> viewHotelCity() throws HotelBookingException {

		ArrayList<String> cityList = new ArrayList<String>();
		try {
			connection = DBUtil.getConnection();

			Statement statement = connection.createStatement();

			ResultSet rs = statement
					.executeQuery(IQueryMapper.VIEW_DESTINATION_CITY);
			while (rs.next()) {

				cityList.add(rs.getString(1));
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return cityList;
	}

	// view available hotels in particular city
	@Override
	public ArrayList<HotelBean> viewHotels(String city)
			throws HotelBookingException {

		ArrayList<HotelBean> hotelList = new ArrayList();

		try {
			connection = DBUtil.getConnection();

			PreparedStatement preparedStatement = connection
					.prepareStatement(IQueryMapper.VIEW_HOTELS);
			preparedStatement.setString(1, city);

			ResultSet resultSet = preparedStatement.executeQuery();

			while (resultSet.next()) {

				HotelBean hotelBean = new HotelBean(resultSet.getInt(1),
						resultSet.getString(2), resultSet.getString(3),
						resultSet.getString(4), resultSet.getDouble(5),
						resultSet.getString(6), resultSet.getString(7),
						resultSet.getInt(8), resultSet.getString(9),
						resultSet.getString(10));

				hotelList.add(hotelBean);

			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return hotelList;
	}

	// filter hotels

	@Override
	public ArrayList<FilterBean> filterHotel(String checkin, String checkout)
			throws HotelBookingException {

		ArrayList<FilterBean> filterList = new ArrayList();
		try {
			connection = DBUtil.getConnection();

			PreparedStatement preparedStatement = connection
					.prepareStatement(IQueryMapper.HOTEL_FILTER_QUERY);
			preparedStatement.setString(1, checkin);
			preparedStatement.setString(2, checkout);
			preparedStatement.setString(3, checkin);

			ResultSet resultSet = preparedStatement.executeQuery();

			while (resultSet.next()) {

				FilterBean filterBean = new FilterBean(resultSet.getInt(1),
						resultSet.getInt(2));

				filterList.add(filterBean);

			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return filterList;
	}

	// book hotel
	@Override
	public int bookHotel(BookingDetailsBean bookingDetailsBean)
			throws HotelBookingException {
		int bookStatus = 0;
		String status = "";
		try {
			connection = DBUtil.getConnection();

			PreparedStatement preparedStatement = connection
					.prepareStatement(IQueryMapper.STATUS_CHECK_QUERY);
			preparedStatement.setInt(1, bookingDetailsBean.getHotelId());
			preparedStatement.setInt(2, bookingDetailsBean.getRoomId());

			ResultSet resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				status = resultSet.getString(1);

			}

			if ("true".equals(status)) {

				preparedStatement = connection
						.prepareStatement(IQueryMapper.BOOK_INSERT_QUERY);
				preparedStatement.setInt(1, bookingDetailsBean.getRoomId());
				preparedStatement.setInt(2, bookingDetailsBean.getUserId());
				preparedStatement.setString(3,
						bookingDetailsBean.getBookedFrom());
				preparedStatement
						.setString(4, bookingDetailsBean.getBookedTo());
				preparedStatement.setInt(5, bookingDetailsBean.getNoOfAdults());
				preparedStatement.setDouble(6, bookingDetailsBean.getAmount());
				preparedStatement.setInt(7, bookingDetailsBean.getHotelId());

				bookStatus = preparedStatement.executeUpdate();

				preparedStatement = connection
						.prepareStatement(IQueryMapper.BOOK_ID_QUERY_SEQUENCE);
				resultSet = preparedStatement.executeQuery();

				while (resultSet.next()) {
					int id = resultSet.getInt(1);

					bookingDetailsBean.setBookingId(id);
					;
				}

			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return bookStatus;
	}

	// view booking status
	@Override
	public ArrayList<BookingDetailsBean> viewBookStatus(int uid) throws HotelBookingException {
		ArrayList<BookingDetailsBean> bookStatusList = new ArrayList();
		try {
			connection = DBUtil.getConnection();

			PreparedStatement preparedStatement = connection
					.prepareStatement(IQueryMapper.VIEW_BOOKING_STATUS_QUERY);
			preparedStatement.setInt(1, uid);

			ResultSet resultSet = preparedStatement.executeQuery();

			while (resultSet.next()) {

				BookingDetailsBean bookingDetailsBean = new BookingDetailsBean(
						resultSet.getInt(1), resultSet.getInt(2),
						resultSet.getInt(3), resultSet.getString(4),
						resultSet.getString(5), resultSet.getInt(6),
						resultSet.getDouble(7), resultSet.getInt(8));

				bookStatusList.add(bookingDetailsBean);

			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return bookStatusList;
	}
	

}
