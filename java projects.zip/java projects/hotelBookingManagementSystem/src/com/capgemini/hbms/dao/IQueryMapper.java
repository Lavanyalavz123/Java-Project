package com.capgemini.hbms.dao;

/********************************************************************************************************
 * 
 * SQL queries
 * 
 **********************************************************************************************************/
public interface IQueryMapper {
	//Hotel methods Query
	public static final String HOTEL_INSERT_QUERY="INSERT INTO HOTEL VALUES(HOTEL_ID_SEQ.NEXTVAL,?,?,?,?,?,?,?,?,?,?)";
	public static final String HOTEL_ID_QUERY_SEQUENCE="SELECT HOTEL_ID_SEQ.CURRVAL FROM DUAL";
	public static final String HOTEL_DELETE_QUERY="DELETE HOTEL WHERE HOTEL_ID=?";
	public static final String VIEW_HOTEL="SELECT * FROM HOTEL WHERE HOTEL_ID=?";
	//Registration Query
	public static final String USER_INSERT_QUERY="INSERT INTO USERS VALUES(USER_ID_SEQ.NEXTVAL,?,?,?,?,?,?)";
	public static final String USER_ID_QUERY_SEQUENCE="SELECT USER_ID_SEQ.CURRVAL FROM DUAL";
	
	//Login Query
	public static final String PASSWORD_VALIDATE_QUERY="SELECT PASSWORD FROM USERS WHERE USER_ID=?";
	//Room methods Query
	
	public static final String ROOM_INSERT_QUERY="INSERT INTO ROOMDETAILS VALUES(?,ROOM_ID_SEQ.NEXTVAL,?,?,?,?)";
	public static final String ROOM_ID_QUERY_SEQUENCE="SELECT ROOM_ID_SEQ.CURRVAL FROM DUAL";
	public static final String ROOM_DELETE_QUERY="DELETE ROOMDETAILS WHERE HOTEL_ID=? AND ROOM_ID=?";
	
	//view Destination city Query to search hotels
	public static final String VIEW_DESTINATION_CITY="SELECT DISTINCT CITY FROM HOTEL";
	//view available hotels in particular city
	public static final String VIEW_HOTELS="SELECT * FROM HOTEL WHERE CITY=?";
	//filter hotel
	public static final String HOTEL_FILTER_QUERY="SELECT hotel_id,room_id FROM roomdetails WHERE (hotel_id,room_id) not in (select hotel_id,room_id from bookingdetails where(booked_from-1 between ? and ?) or (booked_to-1 between ? and ?)";
	//book hotel
	public static final String STATUS_CHECK_QUERY="SELECT AVAILABILITY FROM ROOMDETAILS WHERE ROOM_ID=? AND HOTEL_ID=?";
	public static final String BOOK_INSERT_QUERY="INSERT INTO BOOKINGDETAILS VALUES(BOOK_ID_SEQ.NEXTVAL,?,?,?,?,?,?,?)";
	public static final String BOOK_ID_QUERY_SEQUENCE="SELECT BOOK_ID_SEQ.CURRVAL FROM DUAL";
	
	
	//view booking status query
	public static final String VIEW_BOOKING_STATUS_QUERY="SELECT * FROM BOOKINGDETAILS WHERE USER_ID=?";
}
