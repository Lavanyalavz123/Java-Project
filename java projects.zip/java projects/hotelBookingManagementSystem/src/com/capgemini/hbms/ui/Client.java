package com.capgemini.hbms.ui;

import java.sql.Date;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Scanner;

import com.capgemini.hbms.bean.BookingDetailsBean;
import com.capgemini.hbms.bean.FilterBean;
import com.capgemini.hbms.bean.HotelBean;
import com.capgemini.hbms.bean.RoomDetailsBean;
import com.capgemini.hbms.bean.UsersBean;
import com.capgemini.hbms.exception.HotelBookingException;
import com.capgemini.hbms.service.*;

public class Client {

	public static void main(String[] args) throws HotelBookingException {
		char ch;
		Scanner scanner = new Scanner(System.in);
		do {
			System.out
					.println("---------Hotel Booking Management System------------- ");
			System.out.println();
			System.out.println("Access Categories:");
			System.out.println("1.Customer\n2.Hotel-Employee\n3.Admin");
			System.out.println("Choose option");
			System.out.println();

			UsersBean usersBean = null;

			int option = scanner.nextInt();
			IHotelService service = new HotelServiceImpl();
			switch (option) {
			/********************************************************************
			 * 
			 * 
			 * Customer Functions
			 * 
			 * 
			 *******************************************************************/
			case 1:
				System.out
						.println("1.Register\n2.Login\n3.Search for Hotel Rooms\n4.Book Hotel Rooms\n5.View Booking Status");
				System.out.println("Choose option");
				int option1 = scanner.nextInt();
				switch (option1) {
				/*******************************************************************
				 * 
				 * Customer Registration
				 * 
				 ********************************************************************/
				case 1:
					Scanner scanner1 = new Scanner(System.in);
					usersBean = new UsersBean();

					System.out.println("Enter Name:");
					String name = scanner1.nextLine();

					ArrayList<String> validationErrorsList = new ArrayList<String>();
					// Name Validation
					while (!service.isValidName(name)) {
						validationErrorsList.add(IMsgMapper.NAME_ERROR);
						System.err.println(IMsgMapper.NAME_ERROR);
						name = scanner1.nextLine();
					}

					System.out.println("Enter Address:");
					String address = scanner1.nextLine();
					System.out.println("Enter Mobile Number:");
					String mobile = scanner1.nextLine();
					// Mobile number Validation
					while (!service.isValidMobileNo(mobile)) {
						validationErrorsList.add(IMsgMapper.MOBILE_NO_ERROR);
						System.err.println(IMsgMapper.MOBILE_NO_ERROR);
						mobile = scanner1.nextLine();
					}
					System.out.println("Enter Email:");
					String email = scanner1.nextLine();
					// Email Validation
					while (!service.isValidEmail(email)) {
						validationErrorsList.add(IMsgMapper.EMAIL_ERROR);
						System.err.println(IMsgMapper.EMAIL_ERROR);
						email = scanner1.nextLine();
					}
					System.out
							.println("Set Password:(min 8 characters and maximum 15 characters)");
					String password = scanner1.nextLine();
					// Password Validation
					while (!service.isValidPassword(password)) {
						validationErrorsList.add(IMsgMapper.PASSWORD_ERROR);
						System.err.println(IMsgMapper.PASSWORD_ERROR);
						password = scanner1.nextLine();
					}
					// if (!validationErrorsList.isEmpty()) {

					// }
					String role = "Customer";
					usersBean = new UsersBean(password, role, name, mobile,
							address, email);
					try {
						// Registration Method
						service.registerUser(usersBean);
						System.out
								.println("Regitered Successfully.\nUse below User Id during login\n"
										+ usersBean.getUserId());
					} catch (HotelBookingException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

					break;

				/*********************************************************************************
				 * 
				 * Customer Login
				 * 
				 * 
				 ********************************************************************************/
				case 2:
					service = new HotelServiceImpl();

					Scanner scanner2 = new Scanner(System.in);
					System.out.println("Enter User Id:");
					int uid = scanner.nextInt();
					System.out.println("Enter Password:");
					String upassword = scanner2.nextLine();

					try {
						// Login Validation Method
						int loginStatus = service.loginValidation(uid,
								upassword);
						if (loginStatus == 1) {
							System.out.println("Welcome " + uid);
						} else {
							System.out.println("Not a Valid User");
							System.out.println("Check your credentials");

						}

					} catch (HotelBookingException e) {
						// System.out.println("main");
						e.printStackTrace();
					}

					break;

				/******************************************************************************************
				 * 
				 * Search for Hotel Rooms
				 * 
				 ******************************************************************************************/
				case 3:

					System.out.println("Where are you travelling to ");
					ArrayList<String> cityArrayList = new ArrayList<String>();
					cityArrayList = service.viewHotelCity();
					for (int i = 0; i < cityArrayList.size(); i++) {
						System.out.println((i + 1) + " : "
								+ cityArrayList.get(i));
					}
					System.out.println("Enter city name");
					Scanner scanner4 = new Scanner(System.in);
					String cityOption = scanner4.nextLine();
					System.out.println("Enter Check in date");
					String checkin = scanner4.nextLine();
					// DateTimeFormatter
					// formatter=DateTimeFormatter.ofPattern("dd-MMM-yyyy");
					// LocalDate checkInDate=
					// LocalDate.parse(checkin,formatter);
					// Date checkInDate=Date.valueOf(checkin);
					System.out.println("Enter check out date");
					String checkout = scanner4.nextLine();
					// DateTimeFormatter
					// formatter=DateTimeFormatter.ofPattern("dd-MMM-yyyy");
					// LocalDate checkOutDate=
					// LocalDate.parse(checkout,formatter);
					// Date checkOutDate=Date.valueOf(checkout);

					ArrayList<FilterBean> hotelFilterList = new ArrayList<FilterBean>();
					hotelFilterList = service.filterHotel(checkin, checkout);

					// System.out.println(hotelFilterList);
					int i = 0;
					for (FilterBean filterBean : hotelFilterList) {

						System.out
								.println("hotelid:" + filterBean.getHotelId());
						System.out.println("roomid:" + filterBean.getRoomId());

					}

					/*
					 * 
					 * ArrayList<HotelBean> hotelNameList = new ArrayList();
					 * hotelNameList= service.viewHotels(cityOption);
					 * 
					 * int i=0; for(HotelBean hotelBean:hotelNameList){
					 * System.out
					 * .println("----------Hotel "+i+"-----------------");
					 * System
					 * .out.println("Hotel Name : "+hotelBean.getHotelName());
					 * System.out.println("Address : "+hotelBean.getAddress());
					 * System
					 * .out.println("Contact Number 1 : "+hotelBean.getPhoneNo1
					 * ()); System.out.println("Contact Number 2 : "+hotelBean.
					 * getPhoneNo2());
					 * System.out.println("Email : "+hotelBean.getEmail());
					 * System.out.println("Fax : "+hotelBean.getFax());
					 * System.out.println("Average Cost per Night : "+hotelBean.
					 * getAvgRatePerNight());
					 * System.out.println("Hotel Rating : "
					 * +hotelBean.getRating()); System.out.println();
					 * System.out.println(); }
					 */

					break;
				/******************************************************************************************
				 * 
				 * Book Hotel Rooms
				 * 
				 ******************************************************************************************/
				case 4:

					service = new HotelServiceImpl();
					System.out.println("Register first");
					Scanner scanner3 = new Scanner(System.in);
					scanner = new Scanner(System.in);
					System.out.println("Enter User Id:");
					uid = scanner.nextInt();
					System.out.println("Enter Password:");
					upassword = scanner3.nextLine();

					try {
						int loginStatus = service.loginValidation(uid,
								upassword);
						if (loginStatus == 1) {
							System.out.println("Welcome " + uid);
							System.out.println("Enter hotel id:");
							int hotelId = scanner.nextInt();
							System.out.println("Enter room id:");
							int roomId = scanner.nextInt();

							System.out.println("Enter check in date");
							String bookedFrom = scanner3.nextLine();
							System.out.println("Enter check out date");
							String bookedTo = scanner3.nextLine();
							System.out.println("Enter no of adults");
							int noOfAdults = scanner.nextInt();
							System.out.println("Enter amount");
							Double amount = scanner.nextDouble();
							int userId = uid;
							BookingDetailsBean bookingDetailsBean = new BookingDetailsBean(
									roomId, userId, bookedFrom, bookedTo,
									noOfAdults, amount, hotelId);

							int bookStatus = service
									.bookHotel(bookingDetailsBean);
							if (bookStatus == 1) {
								System.out
										.println("Your booking is successful\n Your booking ID is :"
												+ bookingDetailsBean
														.getBookingId());
							} else {
								System.out.println("Your booking is failed");
							}

						} else {
							System.out.println("Not a Valid User");
						}

					} catch (HotelBookingException e) {
						// System.out.println("main");
						e.printStackTrace();
					}

					break;
				/******************************************************************************************
				 * 
				 * view booking status
				 * 
				 ******************************************************************************************/
				case 5:
					ArrayList<BookingDetailsBean> bookingStatusList = new ArrayList<BookingDetailsBean>();
					service = new HotelServiceImpl();
					System.out.println("Register first to view status");
					Scanner scanner5 = new Scanner(System.in);
					System.out.println("Enter User Id:");
					uid = scanner.nextInt();
					System.out.println("Enter Password:");
					upassword = scanner5.nextLine();

					try {
						int loginStatus = service.loginValidation(uid,
								upassword);
						if (loginStatus == 1) {
							System.out.println("Welcome " + uid);

							bookingStatusList = service.viewBookStatus(uid);
							int s = 1;
							for (BookingDetailsBean bookingDetailsBean : bookingStatusList) {
								System.out.println("----------booking " + s
										+ "-----------------");
								System.out.println("Booking Id : "
										+ bookingDetailsBean.getBookingId());
								System.out.println("Hotel Id : "
										+ bookingDetailsBean.getHotelId());
								System.out.println("Room Id : "
										+ bookingDetailsBean.getHotelId());
								System.out.println("Check In : "
										+ bookingDetailsBean.getBookedFrom());
								System.out.println("Check Out"
										+ bookingDetailsBean.getBookedTo());
								System.out.println("Amount "
										+ bookingDetailsBean.getAmount());

								System.out.println();
								System.out.println();
								s++;
							}

						} else {
							System.out.println("Not a Valid User");
						}

					} catch (HotelBookingException e) {
						// System.out.println("main");
						e.printStackTrace();
					}

					break;

				default:
					System.out.println("Select a valid option");
					break;
				}

				break;
			/**************************************************************************************
			 * 
			 * Hotel Employee functions
			 * 
			 ***************************************************************************************/

			case 2:
				System.out
						.println("1.Register\n2.Login\n3.Search for Hotel Rooms\n4.Book Hotel Rooms\n5.View Booking Status");
				int option2 = scanner.nextInt();
				switch (option2) {
				case 1:

					break;
				case 2:

					break;
				case 3:

					break;
				case 4:

					break;
				case 5:

					break;

				default:
					System.out.println("Enter valid options");
					break;
				}

				break;
			case 3:
				/*********************************************************************************
				 * 
				 * Admin Functions
				 * 
				 *********************************************************************************/

				service = new HotelServiceImpl();
				System.out.println("1.Register\n2.Login");
				System.out.println("choose option");

				scanner = new Scanner(System.in);
				option = scanner.nextInt();
				switch (option) {
				case 1:

					/********************************************************************************
					 * 
					 * Admin Registration
					 * 
					 *********************************************************************************/

					Scanner scanner1 = new Scanner(System.in);
					usersBean = new UsersBean();

					System.out.println("Enter Name:");
					String name = scanner1.nextLine();

					ArrayList<String> validationErrorsList = new ArrayList<String>();
					// Name Validation Method
					while (!service.isValidName(name)) {
						validationErrorsList
								.add("Name must contain only Alphabets");
						System.err.println("Name must contain only Alphabets");
						name = scanner1.nextLine();
					}

					System.out.println("Enter Address:");
					String address = scanner1.nextLine();
					System.out.println("Enter Mobile Number:");
					String mobile = scanner1.nextLine();
					// Mobile number Validation method
					while (!service.isValidMobileNo(mobile)) {
						validationErrorsList
								.add("Mobile Number Should contain 10 numbers");
						System.err
								.println("Mobile Number Should contain 10 numbers");
						mobile = scanner1.nextLine();
					}
					System.out.println("Enter Email:");
					String email = scanner1.nextLine();
					// Email Validation Method
					while (!service.isValidEmail(email)) {
						validationErrorsList.add("Enter valid Email");
						System.err.println("Enter valid Email");
						email = scanner1.nextLine();
					}
					System.out
							.println("Set Password:(min 8 characters and maximum 15 characters)");
					String password = scanner1.nextLine();
					// Password Validation Method
					while (!service.isValidPassword(password)) {
						validationErrorsList
								.add("Password should contain minimum 8 characters and maximum 15 characters");
						System.err
								.println("Password should contain minimum 8 characters and maximum 15 characters");
						password = scanner1.nextLine();
					}
					// if (!validationErrorsList.isEmpty()) {

					// }
					String role = "Admin";
					usersBean = new UsersBean(password, role, name, mobile,
							address, email);
					try {
						// Admin Registration Method
						service.registerUser(usersBean);
						System.out
								.println("Regitered Successfully.\nUse below Admin Id during login\n"
										+ usersBean.getUserId());
					} catch (HotelBookingException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

					break;

				case 2:

					/**************************************************************************************
					 * 
					 * Admin Login
					 * 
					 **************************************************************************************/
					service = new HotelServiceImpl();

					Scanner scanner2 = new Scanner(System.in);
					System.out.println("Enter Admin Id:");
					int uid = scanner.nextInt();
					System.out.println("Enter Password:");
					String upassword = scanner2.nextLine();

					try {
						int loginStatus = service.loginValidation(uid,
								upassword);
						if (loginStatus == 1) {
							System.out.println("Welcome " + uid);

							/**************************************************************************************
							 * 
							 * Admin operations
							 * 
							 ****************************************************************************************/

							System.out
									.println("1.Perform Hotel Management\n2.Perform Room Management\n3.Generate various Reports");
							System.out.println("choose option");
							scanner = new Scanner(System.in);
							option1 = scanner.nextInt();
							switch (option1) {
							case 1:

								/************************************************************************************
								 * 
								 * Hotel Management
								 * 
								 *************************************************************************************/
								System.out
										.println("1.Add Hotel\n2.Update Hotel\n3.Delete Hotel");
								System.out.println("choose option");
								scanner = new Scanner(System.in);
								option2 = scanner.nextInt();

								switch (option2) {

								/************************************************************************************
								 * 
								 * Add Hotel
								 * 
								 *************************************************************************************/
								case 1:
									scanner1 = new Scanner(System.in);
									System.out.println("Enter Hotel Name");

									String hotelName = scanner1.nextLine();
									System.out.println("Enter Hotel Address");
									String hotelAddress = scanner1.nextLine();
									System.out.println("Enter City");
									String city = scanner1.nextLine();
									System.out.println("Enter Phone No1");
									String phoneNo1 = scanner1.nextLine();
									System.out.println("Enter Phone No2");
									String phoneNo2 = scanner1.nextLine();
									System.out.println("Enter Email");
									String hotelEmail = scanner1.nextLine();
									System.out.println("Enter fax");
									String fax = scanner1.nextLine();
									System.out.println("Enter Description");
									String description = scanner1.nextLine();
									System.out
											.println("Enter average cost per night");
									double avgRatePerNight = scanner
											.nextDouble();
									System.out.println("Enter Hotel rating");
									int rating = scanner1.nextInt();

									HotelBean hotelBean = new HotelBean(city,
											hotelName, hotelAddress,
											description, avgRatePerNight,
											phoneNo1, phoneNo2, rating,
											hotelEmail, fax);
									// Add hotel method
									int hotelAddStatus = service
											.addHotel(hotelBean);
									if (hotelAddStatus == 1) {
										System.out
												.println("Hotel added successfully");
									} else {
										System.out
												.println("Hotel is not added");
									}

									break;
								/***********************************************************************************
								 * Update hotel
								 * 
								 ***********************************************************************************/

								case 2:
									ArrayList<HotelBean> hotelList = new ArrayList();
									scanner = new Scanner(System.in);
									System.out
											.println("Enter hotel id to update");
									int hotelId = scanner.nextInt();

									hotelList = service.viewHotel(hotelId);
									 
									for(HotelBean hotelBean1:hotelList)
									{
										System.out.println("Hotel Name : "
												+ hotelBean1.getHotelName());
										System.out.println("Address : "
												+ hotelBean1.getAddress());
										System.out
												.println("Contact Number 1 : "
														+ hotelBean1
																.getPhoneNo1());
										System.out
												.println("Contact Number 2 : "
														+ hotelBean1
																.getPhoneNo2());
										System.out.println("Email : "
												+ hotelBean1.getEmail());
										System.out.println("Fax : "
												+ hotelBean1.getFax());
										System.out
												.println("Average Cost per Night : "
														+ hotelBean1
																.getAvgRatePerNight());
										System.out.println("Hotel Rating : "
												+ hotelBean1.getRating());
										System.out.println();
										System.out.println();
								}
									

									break;
								/***********************************************************************************
								 * Delete hotel
								 * 
								 *************************************************************************************/

								case 3:
									scanner = new Scanner(System.in);
									System.out
											.println("Enter hotel id to delete");
									int deleteHotelId = scanner.nextInt();
									int deleteStatus = service
											.deleteHotel(deleteHotelId);

									if (deleteStatus == 1) {
										System.out.println("Hotel " + deleteHotelId
												+ " deleted Successfully");

									} else {
										System.out.println("Delete failed");
									}

									break;

								default:
									System.out.println("Enter valid option");
									break;
								}

								break;
							/*****************************************************************************
							 * 
							 * Room Management
							 * 
							 ******************************************************************************/
							case 2:
								System.out
										.println("1.Add Room\n2.Update Room\n3.Delete Room");
								System.out.println("choose option");
								scanner = new Scanner(System.in);
								option2 = scanner.nextInt();

								switch (option2) {
								/**************************************************************************
								 * 
								 * Add room
								 * 
								 ***************************************************************************/
								case 1:

									scanner1 = new Scanner(System.in);
									System.out.println("Enter Hotel Id");
									int hotelId = scanner.nextInt();
									System.out.println("Enter Room No");
									String roomNo = scanner1.nextLine();
									System.out.println("Enter Room Type");
									String roomType = scanner1.nextLine();
									System.out.println("Enter cost per night");
									double perNightRate = scanner.nextDouble();
									System.out.println("Enter availability");
									String availability = scanner1.nextLine();

									RoomDetailsBean roomDetailsBean = new RoomDetailsBean(
											hotelId, roomNo, roomType,
											perNightRate, availability);
									// Add room method
									int roomAddStatus = service
											.addRoom(roomDetailsBean);
									if (roomAddStatus == 1) {
										System.out
												.println("Room added Successfuly");
									} else {
										System.out.println("Room not added");
									}

									break;

								/*********************************************************************************
								 * 
								 * update room
								 * 
								 *********************************************************************************/
								case 2:

									break;

								/********************************************************************************
								 * 
								 * Delete room
								 * 
								 ********************************************************************************/
								case 3:
									scanner = new Scanner(System.in);
									System.out.println("Enter hotel id ");
									hotelId = scanner.nextInt();
									System.out
											.println("Enter room id to delete");
									int roomId = scanner.nextInt();

									roomDetailsBean = new RoomDetailsBean();

									roomDetailsBean.setHotelId(hotelId);
									roomDetailsBean.setRoomId(roomId);

									int deleteStatus = service
											.deleteRoom(roomDetailsBean);

									if (deleteStatus == 1) {
										System.out
												.println("Room "
														+ roomId
														+ " deleted Successfully in Hotel"
														+ hotelId);

									} else {
										System.out.println("Delete failed");
									}

									break;

								default:
									System.out.println("Enter valid option");
									break;
								}

								break;

							/*************************************************************************************
							 * 
							 * Generate Reports
							 * 
							 *************************************************************************************/

							case 3:

								break;
							default:
								System.out.println("Enter valid option");
								break;
							}

						} else {
							System.out.println("Not a Valid User");
							System.out
									.println("Check your credentials and re-enter ID and Password");

						}

					} catch (HotelBookingException e) {
						// System.out.println("main");
						e.printStackTrace();
					}

					break;
				default:
					System.out.println("Enter valid option");
					break;
				}

			default:
				System.out.println("Enter valid option");
				break;
			}
			System.out.println("Do you want to continue? Yes or No");
			ch = scanner.next().charAt(0);
		} while (ch == 'y' || ch == 'Y');
	}
}
