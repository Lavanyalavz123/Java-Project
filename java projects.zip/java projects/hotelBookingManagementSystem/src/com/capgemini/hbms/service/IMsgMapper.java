package com.capgemini.hbms.service;

public interface IMsgMapper {
	
	
	public static final String NAME_ERROR= "Name must contain only Alphabets";
	public static final String MOBILE_NO_ERROR= "Mobile Number Should contain 10 numbers";
	public static final String PASSWORD_ERROR= "Password should contain minimum 8 characters and maximum 15 characters";
	public static final String EMAIL_ERROR= "Enter valid Email";
	
	

}
