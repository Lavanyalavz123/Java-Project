package com.capgemini.hbms.service;


import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.hbms.bean.BookingDetailsBean;
import com.capgemini.hbms.bean.FilterBean;
import com.capgemini.hbms.bean.HotelBean;
import com.capgemini.hbms.bean.RoomDetailsBean;
import com.capgemini.hbms.bean.UsersBean;
import com.capgemini.hbms.dao.HotelDAOImpl;
import com.capgemini.hbms.dao.IHotelDAO;
import com.capgemini.hbms.exception.HotelBookingException;

public class HotelServiceImpl implements IHotelService {

	UsersBean UsersBean = new UsersBean();
	IHotelDAO hotelDAO = null;
	
	
	/*****************************************************************************************************
	 * 
	 * Hotel Methods
	 * 
	 *****************************************************************************************************/
	
	// add hotel
	@Override
	public int addHotel(HotelBean hotelBean) throws HotelBookingException {
		
		hotelDAO = new HotelDAOImpl();
		
		
		return hotelDAO.addHotel(hotelBean);
	}
//delete hotel
	@Override
	public int deleteHotel(int id) throws HotelBookingException {
		hotelDAO = new HotelDAOImpl();
		return hotelDAO.deleteHotel(id);
	}
	//view specific hotel details for modification
	@Override
	public ArrayList<HotelBean> viewHotel(int hotelId) throws HotelBookingException {
		hotelDAO = new HotelDAOImpl();
		return hotelDAO.viewHotel(hotelId);
	}
	@Override
	public int modifyHotel(HotelBean hotelBean) throws HotelBookingException {
		// TODO Auto-generated method stub
		return 0;
	}
/*******************************************************************************************************************
 * 
 * room methods
 * 
 ********************************************************************************************************************/
	@Override
	public int addRoom(RoomDetailsBean roomDetailsBean)
			throws HotelBookingException {
		
		hotelDAO = new HotelDAOImpl();
		
		return hotelDAO.addRoom(roomDetailsBean);
	}
//delete room
	@Override
	public int deleteRoom(RoomDetailsBean roomDetailsBean)
			throws HotelBookingException {
		hotelDAO = new HotelDAOImpl();
		return hotelDAO.deleteRoom(roomDetailsBean);
	}

	@Override
	public int modifyRoom(RoomDetailsBean roomDetailsBean)
			throws HotelBookingException {
		// TODO Auto-generated method stub
		return 0;
	}

	/*
	 * 
	 * validation methods
	 */
	@Override
	public boolean isValidName(String name) {
		Pattern pattern = Pattern.compile("[A-Za-z\b]{2,}");
		Matcher matcher = pattern.matcher(name);

		return matcher.matches();

	}
	@Override
	public boolean isValidRole(String roll) {
		if ("Admin".equals(roll))
			return true;
		else if ("Employee".equals(roll))
			return true;
		else if ("Customer".equals(roll))
			return true;
		return false;
	}
	@Override
	public boolean isValidMobileNo(String mobile) {
		Pattern pattern = Pattern.compile("^[7-9]{1}[0-9]{9}");
		Matcher matcher = pattern.matcher(mobile);

		return matcher.matches();

	}
	@Override
	public boolean isValidEmail(String email) {
		Pattern pattern = Pattern
				.compile("^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$");
		Matcher matcher = pattern.matcher(email);

		return matcher.matches();

	}
	@Override
	public boolean isValidPassword(String password) {
		Pattern pattern = Pattern.compile("[A-Za-z0-9.?!@#$%^&*-_]{8,15}");
		Matcher matcher = pattern.matcher(password);

		return matcher.matches();

	}
/*
 * Registration method
 * 
 */
	@Override
	public int registerUser(UsersBean usersBean)
			throws HotelBookingException {
		hotelDAO = new HotelDAOImpl();
		
		return hotelDAO.registerUser(usersBean);
	}
/*
 * 
 * Login Method
 * 
 */
	@Override
	public int loginValidation(int id, String password)
			throws HotelBookingException {
		
		hotelDAO = new HotelDAOImpl();
		
		return hotelDAO.loginValidation(id,password);
	}
/************************************************************************************************
 * Search Hotel Methods
 * 
 **************************************************************************************************/
	@Override
	//view Destination city to search hotels
	public ArrayList<String> viewHotelCity() throws HotelBookingException {
		hotelDAO = new HotelDAOImpl();
		return hotelDAO.viewHotelCity();
	}
//view available hotels in particular city
@Override
public ArrayList<HotelBean> viewHotels(String city) throws HotelBookingException {
	hotelDAO = new HotelDAOImpl();
	return hotelDAO.viewHotels(city);
}
//filter hotels
@Override
public ArrayList<FilterBean> filterHotel(String checkin,String checkout)
		throws HotelBookingException {
	hotelDAO = new HotelDAOImpl();
	return hotelDAO.filterHotel(checkin,checkout);
}

//book hotels
@Override
public int bookHotel(BookingDetailsBean bookingDetailsBean) throws HotelBookingException {
	hotelDAO = new HotelDAOImpl();
	return hotelDAO.bookHotel(bookingDetailsBean);
}
//view booking status

@Override
public ArrayList<BookingDetailsBean> viewBookStatus(int uid) throws HotelBookingException {
	hotelDAO = new HotelDAOImpl();
	return hotelDAO.viewBookStatus(uid);
}


}

