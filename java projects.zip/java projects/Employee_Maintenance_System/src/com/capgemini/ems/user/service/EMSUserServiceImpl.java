package com.capgemini.ems.user.service;

import java.sql.SQLException;

import com.capgemini.ems.exception.EMSProblemException;
import com.capgemini.ems.user.dao.EMSUserDAOImpl;
import com.capgemini.ems.user.dao.IEMSUserDAO;

public class EMSUserServiceImpl implements IEMSUserService {
	IEMSUserDAO emsDao=null;
	
	@Override
	public int searchById(String id) throws EMSProblemException, SQLException {
		emsDao=new EMSUserDAOImpl();
		return emsDao.searchById(id);
	}

	@Override
	public int searchByFname(String fname) throws EMSProblemException, SQLException {
		emsDao=new EMSUserDAOImpl();
		return emsDao.searchByFname(fname);
	}
	
	@Override
	public int searchByLname(String lname) throws EMSProblemException, SQLException {
		emsDao=new EMSUserDAOImpl();
		return emsDao.searchByLname(lname);
	}

	@Override
	public int searchByDeptCode(String deptCode) throws EMSProblemException, SQLException {
		emsDao=new EMSUserDAOImpl();
		return emsDao.searchByDeptCode(deptCode);
	}

	@Override
	public int searchByGrade(String grade) throws EMSProblemException, SQLException {
		emsDao=new EMSUserDAOImpl();
		return emsDao.searchByGrade(grade);
	}
	
	@Override
	public int searchByStatus(String status) throws EMSProblemException, SQLException {
		emsDao=new EMSUserDAOImpl();
		return emsDao.searchByStatus(status);
	}

}
