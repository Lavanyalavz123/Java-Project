package com.capgemini.ems.user.ui;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;

import org.apache.log4j.Logger;

import com.capgemini.ems.bean.EmployeeBean;
import com.capgemini.ems.bean.LeaveHistoryBean;
import com.capgemini.ems.exception.EMSProblemException;
import com.capgemini.ems.user.service.EMSLeaveMaintainenceServiceImpl;
import com.capgemini.ems.user.service.IEMSLeaveMaintainenceService;

public class UILeaveMaintainence {
	static Logger log = Logger.getRootLogger();
	IEMSLeaveMaintainenceService emsServ = null;
	int type, back = 0, repeat = 1, flag = 0, loop = 0, check = 0,dateCheck= 0;
	Scanner scanner = new Scanner(System.in);
	EmployeeBean employee = null;
	LeaveHistoryBean leave = null;
	HashMap<LeaveHistoryBean, EmployeeBean> list = new HashMap<>();
	String from = null, to = null, status = null;

	public int leaveMaintainence(String uname) throws EMSProblemException,
			SQLException, InputMismatchException {
		int choice = 0;
		System.out.println("Welcome to Leave Maintainence");
		System.out.println("*****************************************");
		type = validateUser(uname);
		if (type == 0) {
			do {
				System.out.println("***************************************");
				System.out.println("**-----------------------------------**");
				System.out.println("**|       1. View Details           |**");
				System.out.println("**|       2. Apply for Leave        |**");
				System.out.println("**|       3. Go back to Homepage    |**");
				System.out.println("**|       4. Exit                   |**");
				System.out.println("**-----------------------------------**");
				System.out.println("***************************************");
				choice = scanner.nextInt();
				switch (choice) {
				case 1:
					list = viewLeave(uname);
					viewDetails(list);
					while (loop == 0) {
						System.out.println();
						System.out.println("*****************************************");
						System.out.println("**-----------------------------------****");
						System.out.println("**| 1. Go back to Leave Maintainence  |**");
						System.out.println("**| 2. Go back to Home Page           |**");
						System.out.println("**| 3. Exit                           |**");
						System.out.println("**-------------------------------------**");
						System.out.println("*****************************************");
						choice = scanner.nextInt();
						switch (choice) {
						case 1:
							loop = 1;
							back = 0;
							repeat = 1;
							break;
						case 2:
							loop = 1;
							back = 1;
							repeat = 0;
							break;
						case 3:
							System.out.println("Exiting.....");
							System.exit(0);
							break;
						default:
							System.out.println("Wrong Choice");
							log.error("User entered an option which was not described.");
							loop = 0;
							break;
						}
					}
					break;

				case 2:
					do {
						while(dateCheck == 0){
							System.out
									.println("Enter the date from when you want to apply ");
							from = scanner.next();
							dateCheck = validateDate(from);
							}
							dateCheck = 0;
							while(dateCheck == 0){
							System.out
									.println("Enter the date till when you want to apply ");
							to = scanner.next();
							dateCheck = validateDate(to);
							}
						flag = validateLeave(from, to);
						if (flag == 1) {
							System.out
									.println("From-Date cannot be today or before");
							repeat = 1;
						} else if (flag == 2) {
							System.out
									.println("To-Date cannot be before From-Date");
							repeat = 1;
						} else if (flag == 3) {
							System.out
									.println("Cannot take leave for more than 12 days");
							repeat = 1;
						} else {
							System.out.println("Leave applied for "
									+ applyLeave(uname, from, to) + " day(s)");
							loop = 0;
							while (loop == 0) {
								System.out.println();
								System.out.println("*****************************************");
								System.out.println("**------------------------------------***");
								System.out.println("**| 1. Go back to Leave Maintainence  |**");
								System.out.println("**| 2. Go back to Home Page           |**");
								System.out.println("**| 3. Exit                           |**");
								System.out.println("**-------------------------------------**");
								System.out.println("*****************************************");
								choice = scanner.nextInt();
								switch (choice) {
								case 1:
									back = 0;
									repeat = 1;
									loop = 0;
									break;
								case 2:
									back = 1;
									repeat = 0;
									loop = 1;
									break;
								case 3:
									System.out.println("Exiting.....");
									System.exit(0);
									break;
								default:
									System.out.println("Wrong Choice");
									log.error("User entered an option which was not described.");
									loop = 0;
								}
							}
						}
					} while (repeat == 1);
					break;

				case 3:
					back = 1;
					repeat = 0;
					break;

				case 4:
					System.out.println("Exiting...");
					System.exit(0);
					break;

				default:
					System.out.println("Wrong Choice");
					log.error("User entered an option which was not described.");
					repeat = 1;
				}
			} while (repeat == 1);
		} else {
			do {
				System.out.println("***************************************");
				System.out.println("**-----------------------------------**");
				System.out.println("**|       1. View Details           |**");
				System.out.println("**|       2. Apply for Leave        |**");     
				System.out.println("**|       3. Approve/Reject Leaves  |**");
				System.out.println("**|       4. Go back to Homepage    |**");
				System.out.println("**|       5. Exit                   |**");
				System.out.println("**-----------------------------------**");
				System.out.println("***************************************");
				choice = scanner.nextInt();
				switch (choice) {
				case 1:
					list = viewLeave(uname);
					viewDetails(list);
					while (loop == 0) {
						System.out.println();
						System.out.println("1. Go back to Leave Maintainence");
						System.out.println("2. Go back to Home Page");
						System.out.println("3. Exit");
						choice = scanner.nextInt();
						switch (choice) {
						case 1:
							loop = 1;
							back = 0;
							repeat = 1;
							break;
						case 2:
							loop = 1;
							back = 1;
							repeat = 0;
							break;
						case 3:
							System.out.println("Exiting.....");
							System.exit(0);
							break;
						default:
							System.out.println("Wrong Choice");
							loop = 0;
							break;
						}
					}
					break;

				case 2:
					do {
						while(dateCheck == 0){
							System.out
									.println("Enter the date from when you want to apply ");
							from = scanner.next();
							dateCheck = validateDate(from);
							}
							dateCheck = 0;
							while(dateCheck == 0){
							System.out
									.println("Enter the date till when you want to apply ");
							to = scanner.next();
							dateCheck = validateDate(to);
							}
						flag = validateLeave(from, to);
						if (flag == 1) {
							System.out
									.println("From-Date cannot be today or before");
							repeat = 1;
						} else if (flag == 2) {
							System.out
									.println("To-Date cannot be before From-Date");
							repeat = 1;
						} else if (flag == 3) {
							System.out
									.println("Cannot take leave for more than 12 days");
							repeat = 1;
						} else {
							System.out.println("Leave applied for "
									+ applyLeave(uname, from, to) + " day(s)");
							loop = 0;
							while (loop == 0) {
								System.out.println();
								System.out
										.println("1. Go back to Leave Maintainence");
								System.out.println("2. Go back to Home Page");
								System.out.println("3. Exit");
								choice = scanner.nextInt();
								switch (choice) {
								case 1:
									back = 0;
									repeat = 1;
									loop = 0;
									break;
								case 2:
									back = 1;
									repeat = 0;
									loop = 1;
									break;
								case 3:
									System.out.println("Exiting.....");
									System.exit(0);
									break;
								default:
									System.out.println("Wrong Choice");
									log.error("User entered an option which was not described.");
									loop = 0;
								}
							}
						}
					} while (repeat == 1);
					break;

				case 3:
					statusLeave(uname);
					loop = 0;
					while (loop == 0) {
						System.out.println();
						System.out.println("*********************************************");
						System.out.println("**-----------------------------------------**");
						System.out.println("**|      1.Approve/Reject                 |**");
						System.out.println("**|      2.Go back to Leave Maintainence  |**");
						System.out.println("**|      3. Go back to Homepage           |**");
						System.out.println("**|      4. Exit                          |**");
						System.out.println("**-----------------------------------------**");
						System.out.println("*********************************************");
						choice = scanner.nextInt();
						switch (choice) {
						case 1:
							System.out.println("Enter employee id");
							String id = scanner.next();
							check = checkApproved(id);
							if(check == 4){
								System.out.println("Status is already rejected");
							}
							else if(check == 3){
								System.out.println("Status is already approved");
							}
							else if(check == 2){
								System.out.println("Employee has not yet applied for leave");
							}
							while(check == 0){
							System.out.println("Approve OR Reject");
							status = scanner.next();
							check = validateStatus(status);
							if(check == 0)
								System.out.println("Invalid Action");
							}
							if(check == 1)
							statusAction(id, status);
							break;
						case 2:
							loop = 1;
							back = 0;
							repeat = 1;
							break;
						case 3:
							loop = 1;
							back = 1;
							repeat = 0;
							break;
						case 4:
							System.out.println("Exiting.....");
							System.exit(0);
							break;
						default:
							System.out.println("Wrong Choice");
							loop = 0;
							break;
						}
					}
					break;

				case 4:
					back = 1;
					repeat = 0;
					break;

				case 5:
					System.out.println("Exiting...");
					System.exit(0);
					break;

				default:
					System.out.println("Wrong Choice");
					repeat = 1;
				}
			} while (repeat == 1);
		}
		return back;
	}

	private int validateDate(String dateToBeChecked) throws EMSProblemException {
		emsServ = new EMSLeaveMaintainenceServiceImpl();
		return emsServ.validateDate(dateToBeChecked);
	}

	private int checkApproved(String id) throws SQLException, EMSProblemException {
		emsServ = new EMSLeaveMaintainenceServiceImpl();
		return emsServ.checkApproved(id);
	}

	private int statusAction(String id, String status) throws EMSProblemException, SQLException {
		emsServ = new EMSLeaveMaintainenceServiceImpl();
		return emsServ.statusAction(id,status);
	}

	private int validateStatus(String status) {
		emsServ = new EMSLeaveMaintainenceServiceImpl();
		return emsServ.validateStatus(status);
	}

	private void statusLeave(String uname) throws EMSProblemException,
			SQLException {
		emsServ = new EMSLeaveMaintainenceServiceImpl();
		emsServ.statusLeave(uname);
	}

	private int validateLeave(String from, String to)
			throws EMSProblemException, SQLException {
		emsServ = new EMSLeaveMaintainenceServiceImpl();
		return emsServ.validateLeave(from, to);
	}

	private int applyLeave(String uname, String from, String to)
			throws EMSProblemException, SQLException {
		emsServ = new EMSLeaveMaintainenceServiceImpl();
		return emsServ.applyLeave(uname, from, to);
	}

	@SuppressWarnings("rawtypes")
	private void viewDetails(HashMap<LeaveHistoryBean, EmployeeBean> list) {
		Iterator<Entry<LeaveHistoryBean, EmployeeBean>> it = list.entrySet()
				.iterator();
		while (it.hasNext()) {
			Map.Entry pair = (Map.Entry) it.next();
			employee = (EmployeeBean) pair.getValue();
			System.out.println("Employee Id = " + employee.getEmp_id());
			System.out.println("Name = " + employee.getEmp_first_name() + " "
					+ employee.getEmp_last_name());
			leave = (LeaveHistoryBean) pair.getKey();
			System.out.println("Leave Balance = " + leave.getLeave_balance());
			System.out.println("From Date = " + leave.getDate_from());
			System.out.println("To Date = " + leave.getDate_to());
			System.out
					.println("No. of days = " + leave.getNoofdays_applied());
			System.out.println("Status = " + leave.getStatus());
			System.out.println();
			System.out.println("*****************************************");

		}
	}

	private HashMap<LeaveHistoryBean, EmployeeBean> viewLeave(String uname)
			throws EMSProblemException, SQLException {
		emsServ = new EMSLeaveMaintainenceServiceImpl();
		return emsServ.viewLeave(uname);
	}

	private int validateUser(String uname) throws EMSProblemException,
			SQLException {
		emsServ = new EMSLeaveMaintainenceServiceImpl();
		return emsServ.validateUser(uname);
	}

}

/*
 * System.out.println("1. View Details");
 * System.out.println("2. Apply for Leave");
 * System.out.println("3. Approve/Reject Leaves");
 * System.out.println("4. Go back to Homepage"); System.out.println("5. Exit");
 */
