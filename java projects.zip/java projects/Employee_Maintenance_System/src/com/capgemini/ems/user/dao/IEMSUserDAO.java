package com.capgemini.ems.user.dao;

import java.sql.SQLException;

import com.capgemini.ems.exception.EMSProblemException;

public interface IEMSUserDAO {
	public abstract int searchById(String id)throws EMSProblemException, SQLException;
	public abstract int searchByFname(String fname)throws EMSProblemException, SQLException;
	public abstract int searchByLname(String lname)throws EMSProblemException, SQLException;
	public abstract int searchByDeptCode(String deptCode)throws EMSProblemException, SQLException;
	public abstract int searchByGrade(String grade)throws EMSProblemException, SQLException;
	public abstract int searchByStatus(String status)throws EMSProblemException, SQLException;
}
