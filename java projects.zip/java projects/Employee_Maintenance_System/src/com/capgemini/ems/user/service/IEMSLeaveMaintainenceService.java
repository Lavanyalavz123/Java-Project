package com.capgemini.ems.user.service;

import java.sql.SQLException;
import java.util.HashMap;

import com.capgemini.ems.bean.EmployeeBean;
import com.capgemini.ems.bean.LeaveHistoryBean;
import com.capgemini.ems.exception.EMSProblemException;

public interface IEMSLeaveMaintainenceService {
	public abstract  int validateUser(String uname)throws EMSProblemException, SQLException;
	public abstract HashMap<LeaveHistoryBean, EmployeeBean> viewLeave(String uname)throws EMSProblemException, SQLException;
	public abstract  int applyLeave(String uname, String from, String to)throws EMSProblemException, SQLException;
	public abstract int validateLeave(String from, String to);
	public abstract void statusLeave(String uname) throws EMSProblemException,SQLException;
	public abstract int validateStatus(String status);
	public abstract int statusAction(String id, String status) throws EMSProblemException, SQLException;
	public abstract int checkApproved(String id) throws SQLException, EMSProblemException;
	public abstract int validateDate(String dateToBeChecked) throws EMSProblemException;
}
