package com.capgemini.ems.user.service;

import java.sql.SQLException;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeParseException;
import java.util.HashMap;

import com.capgemini.ems.exception.EMSProblemException;
import com.capgemini.ems.user.dao.EMSLeaveMaintainenceDAOImpl;
import com.capgemini.ems.user.dao.IEMSLeaveMaintainenceDAO;
import com.capgemini.ems.bean.EmployeeBean;
import com.capgemini.ems.bean.LeaveHistoryBean;

public class EMSLeaveMaintainenceServiceImpl implements IEMSLeaveMaintainenceService {
	IEMSLeaveMaintainenceDAO emsDao = null;
	
	@Override
	public int validateUser(String uname) throws EMSProblemException,
			SQLException {
		emsDao=new EMSLeaveMaintainenceDAOImpl();
		return emsDao.validateUser(uname);
	}

	@Override
	public HashMap<LeaveHistoryBean, EmployeeBean> viewLeave(String uname) throws EMSProblemException,
			SQLException {
		emsDao=new EMSLeaveMaintainenceDAOImpl();
		return emsDao.viewLeave(uname);
	}
	
	@Override
	public int applyLeave(String uname, String from, String to) throws EMSProblemException,
			SQLException {
		emsDao=new EMSLeaveMaintainenceDAOImpl();
		LocalDate dateFrom = LocalDate.parse(from);
		LocalDate dateTo = LocalDate.parse(to);
		Period p = Period.between(dateFrom, dateTo);
		return emsDao.applyLeave(uname, from, to, p.getDays());
	}

	@Override
	public int validateLeave(String from, String to) {
		int flag = 0;
		LocalDate dateFrom = LocalDate.parse(from);
		LocalDate dateTo = LocalDate.parse(to);
		LocalDate today = LocalDate.now();
		int test1 = today.compareTo(dateFrom);
		int test2 = dateFrom.compareTo(dateTo);
		if (test1 >= 0 )   // cannot be today or before
			flag = 1;
		else if ( test2 > 0 ) // cannot be before from 
			flag = 2;
		else if (test2 < -12) // cannot take more than 12
			flag = 3;
		else flag = 0;
		return flag;
	}

	@Override
	public void statusLeave(String uname) throws EMSProblemException,SQLException {
		emsDao=new EMSLeaveMaintainenceDAOImpl();
		emsDao.statusLeave(uname);
	}

	@Override
	public int validateStatus(String status) {
		int check = 0;
		if(("Approve".equalsIgnoreCase(status))||("Reject".equalsIgnoreCase(status))){
			check = 1;
		}
		
		else check = 0;
		return check;
	}

	@Override
	public int statusAction(String id, String status)throws EMSProblemException, SQLException {
		emsDao=new EMSLeaveMaintainenceDAOImpl();
		if("Approve".equalsIgnoreCase(status)){
			status = "approved";
		}
		else if ("Reject".equalsIgnoreCase(status)){
			status = "rejected";
		}
		return emsDao.statusAction(id,status);
	}

	@Override
	public int checkApproved(String id) throws SQLException, EMSProblemException {
		emsDao=new EMSLeaveMaintainenceDAOImpl();
		return emsDao.checkApproved(id);
	}

	@Override
	public int validateDate(String dateToBeChecked) throws EMSProblemException {
		try{
			LocalDate.parse(dateToBeChecked);
		}catch(DateTimeParseException e){
			System.out.println("Invalid Date Format");
			System.out.println(e);
			return 0;
		}
		return 1;
	}
	
	/*public static void main(String[] args) {
		EMSLeaveMaintainenceServiceImpl testing = new EMSLeaveMaintainenceServiceImpl();
		testing.validateLeave("2018-09-04", "2018-09-05");
		
	}*/

}
