package com.capgemini.ems.user.dao;

public interface IQueryMapper {
	public static final String FIND_EMP_ID="SELECT * FROM Employee where emp_id = ?";
	public static final String FIND_EMP_FNAME="SELECT * FROM Employee where lower(emp_first_name) LIKE ? ";
	public static final String FIND_EMP_LNAME="SELECT * FROM Employee where emp_last_name = ?";
	public static final String FIND_EMP_DEPT_CODE="SELECT * FROM Employee where emp_dept_id = ?";
	public static final String FIND_EMP_GRADE="SELECT * FROM Employee where emp_grade = ?";
	public static final String FIND_EMP_STATUS="SELECT * FROM Employee where emp_marital_status = ?";
	
	public static final String VIEW_DETAILS="SELECT * FROM leave_history l,employee e WHERE e.emp_id in(select userid from user_master where username = ?) and e.emp_id = l.emp_id";
	public static final String SELECT_TYPE="select emp_id from employee where mgr_id in(select userid from user_master where username = ?)";
	public static final String SELECT_EMP_ID="SELECT emp_id, leave_balance FROM leave_history where emp_id in(select userid from user_master where username = ?)";
	public static final String UPDATE_LEAVE="UPDATE leave_history SET leave_balance= ?, noofdays_applied = ?, date_from = ?, date_to=?, status=?, leave_applied_on=? where emp_id=?";
	public static final String INSERT_LEAVE="INSERT into leave_history values (leave_seq.nextval, ?,?,?,?,?,'applied',sysdate)";
	public static final String VIEW_STATUS="select e.emp_id, e.emp_first_name, e.emp_last_name, l.date_from, l.date_to, l.noofdays_applied, l.status from leave_history l, employee e where e.emp_id = l.emp_id and l.leave_applied_on in (select  max(leave_applied_on) from LEAVE_HISTORY group by leave_id)and e.emp_id in (select emp_id from employee where mgr_id = ?)";
	public static final String UPDATE_STATUS="UPDATE leave_history SET status = ? where emp_id = ? and leave_applied_on in (select  max(leave_applied_on) from LEAVE_HISTORY group by leave_id)";
	public static final String SELECT_STATUS="SELECT status from leave_history where emp_id=? and leave_applied_on in (select  max(leave_applied_on) from LEAVE_HISTORY group by leave_id)";
	
	public static final String REJECT_CASE="UPDATE leave_history SET leave_balance = ? where emp_id = ?";
	public static final String SELECT_DAYS="SELECT noofdays_applied, leave_balance from leave_history where emp_id = ? and leave_applied_on in (select  max(leave_applied_on) from LEAVE_HISTORY group by leave_id)";
	}
	


