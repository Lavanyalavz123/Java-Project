package com.capgemini.ems.user.ui;

import java.sql.SQLException;
import java.util.Scanner;

import com.capgemini.ems.bean.EmployeeBean;
import com.capgemini.ems.exception.EMSProblemException;
import com.capgemini.ems.user.service.EMSUserServiceImpl;
import com.capgemini.ems.user.service.IEMSUserService;

public class UISearchEmployee {
	EmployeeBean empbean = new EmployeeBean();
	Scanner scanner = new Scanner(System.in);

	public int searchEmployee() throws EMSProblemException, SQLException {
		int check = 0, repeat = 1, back = 0, loop = 0;
		String choice = null;
		do {
			System.out.println("Search for employee based on");
			System.out.println("1. Employee ID");
			System.out.println("2. First Name");
			System.out.println("3. Last Name");
			System.out.println("4. Department");
			System.out.println("5. Grade");
			System.out.println("6. Marital Status");
			System.out.println("7. Go back to Home Page");
			System.out.println("8. Exit");
			int option = scanner.nextInt();
			switch (option) {
			case 1:
				while (check == 0) {
					System.out.println("Enter the Employee Id");
					String id = scanner.next();
					check = searchById(id);
				}
				check = 0;
				repeat = 1;
				break;

			case 2:
				while (check == 0) {
					System.out.println("Enter First Name");
					String fname = scanner.next();
					check = searchByFname(fname);
				}
				check = 0;
				repeat = 1;
				break;

			case 3:
				while (check == 0) {
					System.out.println("Enter Last Name");
					String lname = scanner.next();
					check = searchByLname(lname);
				}
				check = 0;
				repeat = 1;
				break;

			case 4:
				while (check == 0) {
					System.out.println("Enter Department Code");
					String deptCode = scanner.next();
					check = searchByDeptCode(deptCode);
				}
				check = 0;
				repeat = 1;
				break;

			case 5:
				while (check == 0) {
					System.out.println("Enter Grade");
					String grade = scanner.next();
					check = searchByGrade(grade);
				}
				check = 0;
				repeat = 1;
				break;

			case 6:
				while (check == 0) {
					System.out.println("Enter Marital Status");
					String status = scanner.next();
					check = searchByStatus(status);
				}
				check = 0;
				repeat = 1;
				break;

			case 7:
				back = 1;
				repeat = 0;
				break;

			case 8:
				System.out.println("Exiting...");
				System.exit(0);
				break;

			default:
				System.out.println("Wrong Choice Entered");
				repeat = 1;
				break;
			}
			while (repeat == 1) {
				repeat = 0;
				System.out.println();
				System.out
						.println("Do you want to search for employee using any other criteria or go back?");
				System.out.println("Press Y to continue search or any other key to go back");
				choice = scanner.next();
				if ("Y".equalsIgnoreCase(choice))
					loop = 0;
				else {
					loop = 1;
					back = 1;
				}
			}
		} while (loop == 0);
		return back;
	}

	IEMSUserService emsServ = null;

	private int searchById(String id) throws EMSProblemException, SQLException {
		emsServ = new EMSUserServiceImpl();
		return emsServ.searchById(id);
	}

	private int searchByFname(String fname) throws EMSProblemException,
			SQLException {
		emsServ = new EMSUserServiceImpl();
		return emsServ.searchByFname(fname);
	}

	private int searchByLname(String lname) throws EMSProblemException,
			SQLException {
		emsServ = new EMSUserServiceImpl();
		return emsServ.searchByLname(lname);
	}

	private int searchByDeptCode(String deptCode) throws EMSProblemException,
			SQLException {
		emsServ = new EMSUserServiceImpl();
		return emsServ.searchByDeptCode(deptCode);
	}

	private int searchByGrade(String grade) throws EMSProblemException,
			SQLException {
		emsServ = new EMSUserServiceImpl();
		return emsServ.searchByGrade(grade);
	}

	private int searchByStatus(String status) throws EMSProblemException,
			SQLException {
		emsServ = new EMSUserServiceImpl();
		return emsServ.searchByStatus(status);
	}
}
