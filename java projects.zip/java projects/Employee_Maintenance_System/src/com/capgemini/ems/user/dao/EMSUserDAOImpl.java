package com.capgemini.ems.user.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import com.capgemini.ems.user.dao.IQueryMapper;
import com.capgemini.ems.bean.EmployeeBean;
import com.capgemini.ems.exception.EMSProblemException;
import com.capgemini.ems.util.DBUtil;

public class EMSUserDAOImpl implements IEMSUserDAO {
	EmployeeBean employee = new EmployeeBean();
	private Connection conn = null;
	String option = null, choice = null, name = null;

	Scanner scanner = new Scanner(System.in);

	@Override
	public int searchById(String id) throws EMSProblemException, SQLException {

		conn = DBUtil.establishConnection();
		int check = 0;
		PreparedStatement preparedStatement = conn
				.prepareStatement(IQueryMapper.FIND_EMP_ID);
		preparedStatement.setString(1, id);
		ResultSet rs = preparedStatement.executeQuery();

		while (rs.next()) {
			storeIntoObject(rs);
			System.out.println(employee.toString());
			check = 1;
		}

		if (check == 0) {
			System.out.println("Not Found");
		}
		System.out.println("Do you want to search again using Employee Id?");
		System.out
				.println("Press Y to continue search or any other key to go back");
		option = scanner.next();
		if ("Y".equalsIgnoreCase(option)) {
			check = 0;
		} else
			check = 1;

		return check;
	}

	@Override
	public int searchByFname(String fname) throws EMSProblemException,
			SQLException {
		conn = DBUtil.establishConnection();
		int check = 0;
		name = "%" + fname + "%";
		PreparedStatement preparedStatement = conn
				.prepareStatement(IQueryMapper.FIND_EMP_FNAME);
		preparedStatement.setString(1, name);
		ResultSet rs = preparedStatement.executeQuery();
		while (rs.next()) {
			storeIntoObject(rs);
			System.out.println(employee.toString());
			System.out.println();
			check = 1;
		}
		if (check == 0) {
			System.out.println("Not Found");
		}
		System.out.println("Do you want to search again using First Name?");
		System.out
				.println("Press Y to continue search or any other key to go back");
		option = scanner.next();
		if ("Y".equalsIgnoreCase(option)) {
			check = 0;
		} else
			check = 1;

		return check;
	}

	@Override
	public int searchByLname(String lname) throws EMSProblemException,
			SQLException {
		conn = DBUtil.establishConnection();
		int check = 0;
		name = "%" + lname + "%";
		PreparedStatement preparedStatement = conn
				.prepareStatement(IQueryMapper.FIND_EMP_LNAME);
		preparedStatement.setString(1, name);
		ResultSet rs = preparedStatement.executeQuery();
		while (rs.next()) {
			storeIntoObject(rs);
			System.out.println(employee.toString());
			check = 1;
		}
		if (check == 0) {
			System.out.println("Not Found");
		}
		System.out.println("Do you want to search again using First Name?");
		System.out
				.println("Press Y to continue search or any other key to go back");
		option = scanner.next();
		if ("Y".equalsIgnoreCase(option)) {
			check = 0;
		} else
			check = 1;

		return check;
	}

	@Override
	public int searchByDeptCode(String deptCode) throws EMSProblemException,
			SQLException {
		conn = DBUtil.establishConnection();
		int check = 0;
		PreparedStatement preparedStatement = conn
				.prepareStatement(IQueryMapper.FIND_EMP_DEPT_CODE);
		preparedStatement.setString(1, deptCode);
		ResultSet rs = preparedStatement.executeQuery();

		while (rs.next()) {
			storeIntoObject(rs);
			System.out.println(employee.toString());
			check = 1;
		}
		if (check == 0) {
			System.out.println("Not Found");
		}
		System.out
				.println("Do you want to search again using Department Code?");
		System.out
				.println("Press Y to continue search or any other key to go back");
		option = scanner.next();
		if ("Y".equalsIgnoreCase(option)) {
			check = 0;
		} else
			check = 1;

		return check;
	}

	@Override
	public int searchByGrade(String grade) throws EMSProblemException,
			SQLException {
		conn = DBUtil.establishConnection();
		int check = 0;
		PreparedStatement preparedStatement = conn
				.prepareStatement(IQueryMapper.FIND_EMP_GRADE);
		preparedStatement.setString(1, grade);
		ResultSet rs = preparedStatement.executeQuery();

		while (rs.next()) {
			storeIntoObject(rs);
			System.out.println(employee.toString());
			check = 1;
		}
		if (check == 0) {
			System.out.println("Not Found");
		}
		System.out.println("Do you want to search again using Grade Code?");
		System.out
				.println("Press Y to continue search or any other key to go back");
		option = scanner.next();
		if ("Y".equalsIgnoreCase(option)) {
			check = 0;
		} else
			check = 1;

		return check;
	}

	@Override
	public int searchByStatus(String status) throws EMSProblemException,
			SQLException {
		conn = DBUtil.establishConnection();
		int check = 0;
		PreparedStatement preparedStatement = conn
				.prepareStatement(IQueryMapper.FIND_EMP_STATUS);
		preparedStatement.setString(1, status);
		ResultSet rs = preparedStatement.executeQuery();

		while (rs.next()) {
			storeIntoObject(rs);
			System.out.println(employee.toString());
			check = 1;
		}
		if (check == 0) {
			System.out.println("Not Found");
		}
		System.out.println("Do you want to search again using Marital Status?");
		System.out
				.println("Press Y to continue search or any other key to go back");
		option = scanner.next();
		if ("Y".equalsIgnoreCase(option)) {
			check = 0;
		} else
			check = 1;

		return check;
	}

	private void storeIntoObject(ResultSet rs) throws SQLException {
		employee.setEmp_id(rs.getString(1));
		employee.setEmp_first_name(rs.getString(2));
		employee.setEmp_last_name(rs.getString(3));
		employee.setEmp_date_of_birth(rs.getDate(4));
		employee.setEmp_date_of_joining(rs.getDate(5));
		employee.setDept_id(rs.getInt(6));
		employee.setGrade_code(rs.getString(7));
		employee.setEmp_designation(rs.getString(8));
		employee.setEmp_basic(rs.getInt(9));
		employee.setGender(rs.getString(10));
		employee.setEmp_marital_status(rs.getString(11));
		employee.setEmp_home_address(rs.getString(12));
		employee.setEmp_contact_num(rs.getString(13));
		employee.setMgr_id(rs.getString(14));
	}

}
