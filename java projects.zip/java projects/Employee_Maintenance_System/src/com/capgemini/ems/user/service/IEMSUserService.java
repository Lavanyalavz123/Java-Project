package com.capgemini.ems.user.service;

import java.sql.SQLException;

import com.capgemini.ems.exception.EMSProblemException;

public interface IEMSUserService {
	public abstract int searchById(String id)throws EMSProblemException, SQLException;
	public abstract int searchByFname(String fname)throws EMSProblemException, SQLException;
	public abstract int searchByLname(String lname)throws EMSProblemException, SQLException;
	public abstract int searchByDeptCode(String deptCode)throws EMSProblemException, SQLException;
	public abstract int searchByGrade(String grade)throws EMSProblemException, SQLException;
	public abstract int searchByStatus(String status)throws EMSProblemException, SQLException;
}
