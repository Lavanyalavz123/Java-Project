package com.capgemini.ems.user.dao;

import java.sql.SQLException;
import java.util.HashMap;

import com.capgemini.ems.bean.EmployeeBean;
import com.capgemini.ems.bean.LeaveHistoryBean;
import com.capgemini.ems.exception.EMSProblemException;

public interface IEMSLeaveMaintainenceDAO {
	public abstract int validateUser(String uname)throws EMSProblemException, SQLException;
	public abstract HashMap<LeaveHistoryBean, EmployeeBean> viewLeave(String uname)throws EMSProblemException, SQLException;
	public abstract int applyLeave(String uname, String from, String to, int days)throws EMSProblemException, SQLException;
	public abstract void statusLeave(String uname) throws EMSProblemException, SQLException;
	public abstract int statusAction(String id, String status) throws SQLException, EMSProblemException;
	public abstract int checkApproved(String id) throws SQLException, EMSProblemException;
}
