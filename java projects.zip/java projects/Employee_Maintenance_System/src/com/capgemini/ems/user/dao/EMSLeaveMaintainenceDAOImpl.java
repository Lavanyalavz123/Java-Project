package com.capgemini.ems.user.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.HashMap;

import com.capgemini.ems.user.dao.IQueryMapper;
import com.capgemini.ems.bean.EmployeeBean;
import com.capgemini.ems.bean.LeaveHistoryBean;
import com.capgemini.ems.bean.UserMasterBean;
import com.capgemini.ems.exception.EMSProblemException;
import com.capgemini.ems.util.DBUtil;

public class EMSLeaveMaintainenceDAOImpl implements IEMSLeaveMaintainenceDAO {
	EmployeeBean employee = new EmployeeBean();
	UserMasterBean user = new UserMasterBean();
	LeaveHistoryBean leave = new LeaveHistoryBean();
	int type = 0, days, balance, balanceLeft;
	String emp_id = null, status = null;
	final LocalDate today = LocalDate.now();
	final Date sysdate = Date.valueOf(today);

	private Connection conn = null;

	@Override
	public int validateUser(String uname) throws EMSProblemException,
			SQLException {
		conn = DBUtil.establishConnection();

		PreparedStatement preparedStatement1 = conn
				.prepareStatement(IQueryMapper.SELECT_TYPE);
		preparedStatement1.setString(1, uname);
		ResultSet rs1 = preparedStatement1.executeQuery();
		if (rs1.next()) {
			type = 1;
		} else
			type = 0;

		return type;
	}

	@Override
	public HashMap<LeaveHistoryBean, EmployeeBean> viewLeave(String uname)
			throws EMSProblemException, SQLException {

		HashMap<LeaveHistoryBean, EmployeeBean> list = new HashMap<>();
		conn = DBUtil.establishConnection();

		PreparedStatement preparedStatement = conn
				.prepareStatement(IQueryMapper.VIEW_DETAILS);
		preparedStatement.setString(1, uname);
		ResultSet rs = preparedStatement.executeQuery();
		while (rs.next()) {
			EmployeeBean employeeObj = new EmployeeBean();
			LeaveHistoryBean leaveObj = new LeaveHistoryBean();
			employeeObj.setEmp_id(rs.getString(2));
			employeeObj.setEmp_first_name(rs.getString(10));
			employeeObj.setEmp_last_name(rs.getString(11));
			leaveObj.setLeave_balance(rs.getInt(3));
			leaveObj.setDate_from(rs.getDate(5));
			leaveObj.setDate_to(rs.getDate(6));
			leaveObj.setNoofdays_applied(rs.getInt(4));
			leaveObj.setLeaveAppliedOn(rs.getDate(8));
			if ((rs.getDate(8) != null)
					&& ("applied".equalsIgnoreCase(rs.getString(7)))) {
				int compare = sysdate.compareTo(rs.getDate(8));
				if (compare > 0) {
					PreparedStatement preparedStatement1 = conn
							.prepareStatement(IQueryMapper.SELECT_EMP_ID);
					preparedStatement1.setString(1, uname);
					ResultSet rs1 = preparedStatement1.executeQuery();
					while (rs1.next()) {
						emp_id = rs1.getString(1);
					}
					PreparedStatement psmtstatus = conn
							.prepareStatement(IQueryMapper.UPDATE_STATUS);
					psmtstatus.setString(1, "approved");
					psmtstatus.setString(2, emp_id);
					psmtstatus.executeUpdate();
					leaveObj.setStatus("approved");
				}
			} else {
				leaveObj.setStatus(rs.getString(7));
			}
			list.put(leaveObj, employeeObj);
		}
		return list;

	}

	@Override
	public int applyLeave(String uname, String fromDate, String toDate, int days)
			throws EMSProblemException, SQLException {
		Date leaveFrom = Date.valueOf(fromDate);
		Date leaveTo = Date.valueOf(toDate);
		conn = DBUtil.establishConnection();
		PreparedStatement preparedStatement = conn
				.prepareStatement(IQueryMapper.SELECT_EMP_ID);
		preparedStatement.setString(1, uname);
		ResultSet rs = preparedStatement.executeQuery();
		while (rs.next()) {
			emp_id = rs.getString(1);
			balanceLeft = rs.getInt(2);
		}
		PreparedStatement psmt = conn
				.prepareStatement(IQueryMapper.INSERT_LEAVE);
		psmt.setString(1, emp_id);
		psmt.setInt(2, balanceLeft - days);
		psmt.setInt(3, days);
		psmt.setDate(4, leaveFrom);
		psmt.setDate(5, leaveTo);
		psmt.executeUpdate();
		return days;

	}

	@Override
	public void statusLeave(String uname) throws EMSProblemException,
			SQLException {
		conn = DBUtil.establishConnection();
		PreparedStatement preparedStatement = conn
				.prepareStatement(IQueryMapper.SELECT_EMP_ID);
		preparedStatement.setString(1, uname);
		ResultSet rs = preparedStatement.executeQuery();
		while (rs.next()) {
			emp_id = rs.getString(1);
		}
		PreparedStatement psmt = conn
				.prepareStatement(IQueryMapper.VIEW_STATUS);
		psmt.setString(1, emp_id);
		ResultSet rsview = psmt.executeQuery();
		while (rsview.next()) {
			System.out.println("Employee Id = " + rsview.getString(1)
					+ ", Name = " + rsview.getString(2) + " "
					+ rsview.getString(3) + ", Leave from = "
					+ rsview.getDate(4) + ", Leave till = " + rsview.getDate(5)
					+ ", No. of Days applied = " + rsview.getInt(6)
					+ ", Status = " + rsview.getString(7));
			System.out
					.println("------------------------------------------------------------------------------------------------------------");
		}

	}

	@Override
	public int statusAction(String id, String status) throws SQLException,
			EMSProblemException {
		conn = DBUtil.establishConnection();
		// rejected-- add no. of leaves to balance
		if ("rejected".equalsIgnoreCase(status)) {
			PreparedStatement psmtdays = conn
					.prepareStatement(IQueryMapper.SELECT_DAYS);
			psmtdays.setString(1, id);
			ResultSet rsdays = psmtdays.executeQuery();
			while (rsdays.next()) {
				days = rsdays.getInt(1);
				balance = rsdays.getInt(2);
			}
			PreparedStatement psmtreject = conn
					.prepareStatement(IQueryMapper.REJECT_CASE);
			psmtreject.setInt(1, days + balance);
			psmtreject.setString(2, id);
			psmtreject.executeUpdate();

		}
		PreparedStatement preparedStatement = conn
				.prepareStatement(IQueryMapper.UPDATE_STATUS);
		preparedStatement.setString(1, status);
		preparedStatement.setString(2, id);
		int statusUpdate = preparedStatement.executeUpdate();
		if (statusUpdate == 1)
			System.out.println("Leave " + status);
		return statusUpdate;
	}

	@Override
	public int checkApproved(String id) throws SQLException,
			EMSProblemException {
		conn = DBUtil.establishConnection();
		PreparedStatement preparedStatement = conn
				.prepareStatement(IQueryMapper.SELECT_STATUS);
		preparedStatement.setString(1, id);
		ResultSet rs = preparedStatement.executeQuery();
		while (rs.next()) {
			status = rs.getString(1);
		}
		if ("rejected".equalsIgnoreCase(status)){
			return 4;
		}
		else if ("approved".equalsIgnoreCase(status)) {
			return 3;
		} else if (status == null) {
			return 2;
		}
		return 0;
	}

	/*
	 * public static void main(String[] args) throws EMSProblemException,
	 * SQLException { // EMSLeaveMaintainenceDAOImpl test = new
	 * EMSLeaveMaintainenceDAOImpl(); Date date1 = Date.valueOf("2018-09-01"); ;
	 * LocalDate date2 = LocalDate.now(); Date date3 = Date.valueOf(date2); int
	 * com = date3.compareTo(date1); System.out.println(com);
	 * 
	 * }
	 */

}
