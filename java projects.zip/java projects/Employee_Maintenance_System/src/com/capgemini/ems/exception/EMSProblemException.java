package com.capgemini.ems.exception;

public class EMSProblemException extends Exception{
	private static final long serialVersionUID = 1L;
	public EMSProblemException(String message) {
		super(message);
	}
	public EMSProblemException(){
		
	}
}
