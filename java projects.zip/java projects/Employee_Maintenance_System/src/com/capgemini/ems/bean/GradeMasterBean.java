package com.capgemini.ems.bean;

public class GradeMasterBean {
	//public enum Grade_code { M1,M2,M3,M4,M5,M6,M7 }
	/*
	 * M1- Engineer
	 * M2- Software Engineer
	 * M3- Analyst
	 * M4-Senior Analyst
	 * M5- Consultant
	 * M6- Manager
	 * M7- Senior Manager
	 */
	private String grade_code;
	private String description;
	private long min_salary;
	private long max_salary;
	public String getGrade_code() {
		return grade_code;
	}
	public void setGrade_code(String grade_code) {
		this.grade_code = grade_code;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public long getMin_salary() {
		return min_salary;
	}
	public void setMin_salary(int min_salary) {
		this.min_salary = min_salary;
	}
	public long getMax_salary() {
		return max_salary;
	}
	public void setMax_salary(int max_salary) {
		this.max_salary = max_salary;
	}
	
	public GradeMasterBean() {
		
	}
	public GradeMasterBean(String grade_code, String description, int min_salary, int max_salary) {
		this.grade_code = grade_code;
		this.description = description;
		this.min_salary = min_salary;
		this.max_salary = max_salary;
	}
	@Override
	public String toString() {
		return "Grade_Master [grade_code=" + grade_code + ", description=" + description + ", min_salary=" + min_salary
				+ ", max_salary=" + max_salary + "]";
	}
	
}
