package com.capgemini.ems.bean;

import java.sql.Date;
public class EmployeeBean {
	//public enum Grade_code { M1,M2,M3,M4,M5,M6,M7 }
	//public enum Gender { Male,Female }
	//public enum Marital_status {Single, Married, Divorced,Separated,Widowed }
	private String emp_id;
	private String emp_first_name;
	private String emp_last_name;
	private Date emp_date_of_birth;
	private Date emp_date_of_joining;
	private int dept_id;
	private String grade_code;
	private String emp_designation;
	private long emp_basic;
	private String gender;
	private String emp_marital_status;
	private String emp_home_address;
	private String emp_contact_num;
	private String mgr_id;
	public String getEmp_id() {
		return emp_id;
	}
	public void setEmp_id(String emp_id) {
		this.emp_id = emp_id;
	}
	public String getEmp_first_name() {
		return emp_first_name;
	}
	public void setEmp_first_name(String emp_first_name) {
		this.emp_first_name = emp_first_name;
	}
	public String getEmp_last_name() {
		return emp_last_name;
	}
	public void setEmp_last_name(String emp_last_name) {
		this.emp_last_name = emp_last_name;
	}
	public Date getEmp_date_of_birth() {
		return emp_date_of_birth;
	}
	public void setEmp_date_of_birth(Date dob) {
		this.emp_date_of_birth = dob;
	}
	public Date getEmp_date_of_joining() {
		return emp_date_of_joining;
	}
	public void setEmp_date_of_joining(Date emp_date_of_joining) {
		this.emp_date_of_joining = emp_date_of_joining;
	}
	public int getDept_id() {
		return dept_id;
	}
	public void setDept_id(int dept_id) {
		this.dept_id = dept_id;
	}
	public String getGrade_code() {
		return grade_code;
	}
	public void setGrade_code(String grade_code) {
		this.grade_code = grade_code;
	}
	public String getEmp_designation() {
		return emp_designation;
	}
	public void setEmp_designation(String emp_designation) {
		this.emp_designation = emp_designation;
	}
	public long getEmp_basic() {
		return emp_basic;
	}
	public void setEmp_basic(long basic) {
		this.emp_basic = basic;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getEmp_marital_status() {
		return emp_marital_status;
	}
	public void setEmp_marital_status(String emp_marital_status) {
		this.emp_marital_status = emp_marital_status;
	}
	public String getEmp_home_address() {
		return emp_home_address;
	}
	public void setEmp_home_address(String emp_home_address) {
		this.emp_home_address = emp_home_address;
	}
	public String getEmp_contact_num() {
		return emp_contact_num;
	}
	public void setEmp_contact_num(String emp_contact_num) {
		this.emp_contact_num = emp_contact_num;
	}
	public String getMgr_id() {
		return mgr_id;
	}
	public void setMgr_id(String mgr_id) {
		this.mgr_id = mgr_id;
	}
	
	public EmployeeBean() {
		
	}
	public EmployeeBean(String emp_id, String emp_first_name, String emp_last_name, Date emp_date_of_birth,
			Date emp_date_of_joining, int dept_id, String grade_code, String emp_designation, int emp_basic,
			String gender, String emp_marital_status, String emp_home_address, String emp_contact_num,
			String mgr_id) {
		this.emp_id = emp_id;
		this.emp_first_name = emp_first_name;
		this.emp_last_name = emp_last_name;
		this.emp_date_of_birth = emp_date_of_birth;
		this.emp_date_of_joining = emp_date_of_joining;
		this.dept_id = dept_id;
		this.grade_code = grade_code;
		this.emp_designation = emp_designation;
		this.emp_basic = emp_basic;
		this.gender = gender;
		this.emp_marital_status = emp_marital_status;
		this.emp_home_address = emp_home_address;
		this.emp_contact_num = emp_contact_num;
		this.mgr_id = mgr_id;
	}
	@Override
	public String toString() {
		return "Employee Id=" + emp_id + ", First Name=" + emp_first_name + ", Last Name=" + emp_last_name
				+ ", Date of Birth=" + emp_date_of_birth + ", Date of Joining=" + emp_date_of_joining
				+ ", Department Id=" + dept_id + ", Grade Code=" + grade_code + ", Designation=" + emp_designation
				+ ", Basic Salary=" + emp_basic + ", Gender=" + gender + ", Marital_status=" + emp_marital_status
				+ ", Address=" + emp_home_address + ", Contact Number=" + emp_contact_num + ", Manager Id="
				+ mgr_id;
	}
	
	
}
