package com.capgemini.ems.bean;

import java.sql.Date;

public class LeaveHistoryBean {
	private long Leave_Id;
	private String emp_id;
	private int leave_balance;
	private int noofdays_applied;
	private Date date_from;
	private Date date_to;
	private String status;
	private Date leaveAppliedOn;
	
	public long getLeave_Id() {
		return Leave_Id;
	}
	public void setLeave_Id(long leave_Id) {
		Leave_Id = leave_Id;
	}
	public String getEmp_id() {
		return emp_id;
	}
	public void setEmp_id(String emp_id) {
		this.emp_id = emp_id;
	}
	public int getLeave_balance() {
		return leave_balance;
	}
	public void setLeave_balance(int leave_balance) {
		this.leave_balance = leave_balance;
	}
	public int getNoofdays_applied() {
		return noofdays_applied;
	}
	public void setNoofdays_applied(int noofdays_applied) {
		this.noofdays_applied = noofdays_applied;
	}
	public Date getDate_from() {
		return date_from;
	}
	public void setDate_from(Date date_from) {
		this.date_from = date_from;
	}
	public Date getDate_to() {
		return date_to;
	}
	public void setDate_to(Date date_to) {
		this.date_to = date_to;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public LeaveHistoryBean() {
		
	}
	public LeaveHistoryBean(long leave_Id, String emp_id, int leave_balance, int noofdays_applied, Date date_from,
			Date date_to, String status, Date leaveAppliedOn) {
		Leave_Id = leave_Id;
		this.emp_id = emp_id;
		this.leave_balance = leave_balance;
		this.noofdays_applied = noofdays_applied;
		this.date_from = date_from;
		this.date_to = date_to;
		this.status = status;
		this.leaveAppliedOn = leaveAppliedOn;
	}
	@Override
	public String toString() {
		return "Leave Id=" + Leave_Id + ", Employee Id=" + emp_id + ", leave balance=" + leave_balance
				+ ", No. of days Applied=" + noofdays_applied + ", Date from=" + date_from + ", Date to=" + date_to
				+ ", Status=" + status+ ", Date Applied on=" + leaveAppliedOn;
	}
	public Date getLeaveAppliedOn() {
		return leaveAppliedOn;
	}
	public void setLeaveAppliedOn(Date leaveAppliedOn) {
		this.leaveAppliedOn = leaveAppliedOn;
	}
	
}
