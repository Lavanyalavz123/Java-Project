package com.capgemini.ems.ui;

import java.sql.SQLException;
import java.time.format.DateTimeParseException;
import java.util.Scanner;
import org.apache.log4j.Logger;
import com.capgemini.ems.admin.service.EMSAdminServiceImpl;
import com.capgemini.ems.admin.service.IEMSAdminService;
import com.capgemini.ems.admin.ui.UIAddEmployee;
import com.capgemini.ems.admin.ui.UIModifyEmployee;
import com.capgemini.ems.exception.EMSProblemException;
import com.capgemini.ems.user.ui.UILeaveMaintainence;
import com.capgemini.ems.user.ui.UISearchEmployee;

public class EMSMain {
	 static Logger log = Logger.getRootLogger();
	public static void main(String[] args) throws SQLException,
			DateTimeParseException, NullPointerException, EMSProblemException {
		int repeat = 1, back = 0, type = 3, loop = 0;
		Scanner scanner = new Scanner(System.in);
		String choice = null, uname = null, password = null, option, select, newPassword;
		EMSMain emsMain = null;
		System.out.println("---Employee Maintainence System----");
		System.out.println();
		while (type == 3) {
			System.out.println("Enter Username");
			uname = scanner.next();
			System.out.println("Enter Password");
			password = scanner.next();
			emsMain = new EMSMain();
			type = emsMain.checkLogin(uname, password);
		}
		if("userpwd".equals(password)){
			EMSMain pwd = new EMSMain();
			System.out.println("Set new password");
			newPassword= scanner.next();
			pwd.changePassword(uname, newPassword);
			System.out.println("Password successfully updated");
		}
		if (type == 1) {
			do {
				loop = 0;
				System.out.println("*************************************************");
				System.out.println("**      1. Add employee details                **");
				System.out.println("**      2. Modify employee details             **");
				System.out.println("**      3. Display all employee details        **");
				System.out.println("**      4. Exit                                **");
				System.out.println("*************************************************");
				System.out.println();
				System.out.println("Enter your choice");
				option = scanner.next();
				switch (option) {
				case "1":
					while (repeat == 1) {
						UIAddEmployee add = new UIAddEmployee();
						add.addEmpMain();
						System.out
								.println("Do you want to add more employees? (Y/N)");
						choice = scanner.next();
						if ("Y".equalsIgnoreCase(choice)) {
							repeat = 1;
						} else
							repeat = 0;
					}
					break;
				case "2":
					while (repeat == 1) {
						UIModifyEmployee modify = new UIModifyEmployee();
						modify.modifyEmployee();
						System.out
								.println("Do you want to modify again? (Y/N)");
						choice = scanner.next();
						if ("Y".equalsIgnoreCase(choice)) {
							repeat = 1;
						} else
							repeat = 0;
					}
					break;
				case "3":
					emsMain = new EMSMain();
					emsMain.viewEmployeeDetails();
					System.out.println();
					System.out.println("1. Go back to Homepage");
					System.out.println("2. Exit");
					System.out.println("Enter your choice");
					select = scanner.next();
					switch (select) {
					case "1":
						loop = 1;
						break;

					case "2":
						System.out.println("Exiting...");
						System.exit(0);

					default:
						System.out.println("Exiting...");
						System.exit(0);

					}

					break;
				case "4":
					System.out.println("Exiting...");
					System.exit(0);
					break;
				default:
					System.out.println("Invalid Option");
					log.error("User entered an option which was not described.");
					loop=1;
				}
			} while (loop == 1);
		}
		if (type == 2) {
			do {
				back = 0;
				System.out.println("****************************************");
				System.out.println("**        1. Search Employee          **");
				System.out.println("**        2. Leave Maintainence       **");
				System.out.println("**        3. Exit                     **");
				System.out.println("****************************************");
				System.out.println();
				System.out.println("Enter your choice");
				option = scanner.next();
				switch (option) {
				case "1":
					UISearchEmployee search = new UISearchEmployee();
					back = search.searchEmployee();
					break;
				case "2":
					UILeaveMaintainence leave = new UILeaveMaintainence();
					back = leave.leaveMaintainence(uname);
					break;
				case "3":
					System.out.println("Exiting...");
					System.exit(0);
					break;
				default:
					System.out.println("Invalid Option");
					log.error("User entered an option which was not described.");
					back = 1;
				}
			} while (back == 1);
		}
		scanner.close();
	}

	private void changePassword(String uname, String password) throws EMSProblemException, SQLException{
		emsServ = new EMSAdminServiceImpl();
		emsServ.changePassword(uname, password);
	}

	IEMSAdminService emsServ = null;

	public int checkLogin(String uname, String password)
			throws EMSProblemException {
		emsServ = new EMSAdminServiceImpl();
		return emsServ.checkLogin(uname, password);
	}

	public int viewEmployeeDetails() throws EMSProblemException {
		emsServ = new EMSAdminServiceImpl();
		return emsServ.viewEmployeeDetails();
	}
}
