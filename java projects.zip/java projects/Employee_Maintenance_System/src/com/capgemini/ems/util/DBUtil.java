package com.capgemini.ems.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
/**
 * @author kashaikh
 *
 */
public class DBUtil {
	static Connection conn = null;

	public static Connection establishConnection() throws SQLException {

			conn = DriverManager.getConnection(
					"jdbc:oracle:thin:@10.219.34.3:1521:orcl", "trg218",
					"training218");
		
		return conn;
	}
}
