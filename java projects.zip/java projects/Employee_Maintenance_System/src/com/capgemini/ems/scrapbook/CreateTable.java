package com.capgemini.ems.scrapbook;
import java.sql.*;

import com.capgemini.ems.util.DBUtil;
public class CreateTable {
	public static void main (String args []) throws SQLException {
		String user_master = "create table user_master(UserId varchar2(6) primary key, UserName varchar2(15), UserPassword varchar2(50), UserType varchar2(10))";
		String department = "create table department(dept_id int primary key, dept_name varchar2(50))";
		String employee = "create table employee(emp_id varchar2(6) primary key, emp_first_name varchar2(25), Emp_Last_Name VARCHAR2(25), Emp_Date_of_Birth DATE, Emp_Date_of_Joining DATE, Emp_Dept_ID int, Emp_Grade VARCHAR2(2), Emp_Designation VARCHAR2(50), Emp_Basic int, Emp_Gender VARCHAR2(6), Emp_Marital_Status VARCHAR2(10), Emp_Home_Address VARCHAR2(100), Emp_Contact_Num VARCHAR2(15), Mgr_Id varchar2(6))";
		String grade_master = "create table grade_master(Grade_Code VARCHAR2(2), Description VARCHAR2(20), Min_Salary number, Max_Salary number)";
		String leave_history = "create table leave_history(Leave_Id number(6) primary key, emp_id varchar2(6), leave_balance number(2) check (leave_balance>=0), noofdays_applied number, date_from date, date_to date, status varchar2(20) check (status in ('applied','approved','rejected')))";
		Connection conn=DBUtil.establishConnection();
		Statement stmt = null;
		try {
			stmt = conn.createStatement();
			
			stmt.execute("drop table user_master");
			System.out.println("dropped user_master");
			stmt.execute("drop table department");
			System.out.println("dropped department");
			stmt.execute("drop table employee");
			System.out.println("dropped employee");
			stmt.execute("drop table grade_master");
			System.out.println("dropped grade_master");
			stmt.execute("drop table leave_history");
			System.out.println("dropped leave_history");
			
			
			stmt.execute(user_master);
		    System.out.println("Created table User_Master in given database...");
		    
		    stmt.execute(department);
		    System.out.println("Created table Department in given database...");
		   
		    stmt.execute(employee);
		    System.out.println("Created table Employee in given database...");
		    
		    stmt.execute(grade_master);
		    System.out.println("Created table Grade_Master in given database...");
		    
		    stmt.execute(leave_history);
		    System.out.println("Created table Leave_History in given database...");
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		finally {
			if(conn!=null) {
				try {
					conn.close();
				} catch(SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}
}
