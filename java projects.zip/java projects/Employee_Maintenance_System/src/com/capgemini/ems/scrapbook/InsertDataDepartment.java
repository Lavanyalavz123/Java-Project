package com.capgemini.ems.scrapbook;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

import com.capgemini.ems.util.DBUtil;

public class InsertDataDepartment {
	private static Scanner sc;
	public static void main(String args[]) throws SQLException {
		int n;
		sc=new Scanner(System.in);
		Connection conn=DBUtil.establishConnection();
		String insertQuery = "insert into department values(?,?)";
		PreparedStatement pstmt = null;
		try {
			System.out.println("Enter the number of records to be entered");
			n= sc.nextInt();
			pstmt = conn.prepareStatement(insertQuery);
			while(n>0) {
				System.out.println("Enter Department Id");
				int id=sc.nextInt();
				System.out.println("Enter Department Name");
				String name=sc.next();
				pstmt.setInt(1,id);
				pstmt.setString(2,name);
				n--;
				int i=pstmt.executeUpdate();  
				System.out.println(i+" records inserted");
			}
			
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		finally {
			if(conn!=null) {
				try {
					conn.close();
				} catch(SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}
}
