/*package com.capgemini.ems.scrapbook;

import java.sql.*;
import java.util.*;

import com.capgemini.ems.bean.*;
import com.capgemini.ems.util.DBUtil;
public class ViewData {
	
	Connection conn=DBUtil.establishConnection();
	ResultSet rs = null;
	Statement stmt = null;
	String selectRecords = "select * from department";
	public void viewTable() {
	//public static void main(String[] args) {
		
		try {
			stmt = conn.createStatement(); 
			rs=stmt.executeQuery(selectRecords); 
			while(rs.next()){  
		         System.out.print("ID: " + rs.getInt("dept_id"));
		         System.out.print(", Name: " + rs.getString("dept_name")+"\n");
			}    
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		finally {
			if(conn!=null) {
				try {
					conn.close();
				} catch(SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}
	public void insertDataIntoClass() {
		try {
			stmt = conn.createStatement(); 
			rs=stmt.executeQuery(selectRecords); 
			ArrayList<DepartmentBean> deptList= new ArrayList<DepartmentBean>();
			while(rs.next()){  
		         DepartmentBean dept = new DepartmentBean(rs.getInt(1),rs.getString(2));
		         deptList.add(dept);
			}
			
			//deptList.stream().forEach(System.out::println);
			for(DepartmentBean d:deptList) {
				System.out.println(d.getDept_id()+", "+d.getDept_name());
			}
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		finally {
			if(conn!=null) {
				try {
					conn.close();
				} catch(SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}
	
	public static void main(String[] args) {
		ViewData view = new ViewData();
		//view.insertDataIntoClass();
		view.viewTable();
	}
}
*/