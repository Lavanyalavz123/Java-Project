package com.capgemini.ems.admin.dao;

import java.sql.SQLException;

import com.capgemini.ems.bean.DepartmentBean;
import com.capgemini.ems.bean.EmployeeBean;
import com.capgemini.ems.bean.UserMasterBean;
import com.capgemini.ems.exception.EMSProblemException;

public interface IEMSAdminDAO {
	public abstract boolean addEmployeeDetails(EmployeeBean empbean,UserMasterBean userbean, DepartmentBean deptbean)throws EMSProblemException;
	public abstract int checkLogin(String username, String password)throws EMSProblemException;
	public abstract int viewEmployeeDetails() throws EMSProblemException;
	public abstract int validateSalary(long basic, String grade) throws EMSProblemException;
	public abstract void changePassword(String uname,String password) throws EMSProblemException, SQLException;

}
