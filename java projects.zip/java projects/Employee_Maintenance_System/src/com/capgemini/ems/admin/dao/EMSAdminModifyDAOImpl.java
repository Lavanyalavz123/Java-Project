package com.capgemini.ems.admin.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.capgemini.ems.admin.service.EMSAdminServiceImpl;
import com.capgemini.ems.admin.service.IEMSAdminService;
import com.capgemini.ems.exception.EMSProblemException;
import com.capgemini.ems.util.DBUtil;

public class EMSAdminModifyDAOImpl implements IEMSAdminModifyDAO {
	private Connection conn = null;
	IEMSAdminService emsServ = null;
	int check = 0;

	@Override
	public int findEmployeeById(String id) throws EMSProblemException {
		try {
			conn = DBUtil.establishConnection();
			PreparedStatement preparedStatement = conn
					.prepareStatement(IQueryMapper.FIND_EMPLOYEE);
			preparedStatement.setString(1, id);
			ResultSet rs = preparedStatement.executeQuery();
			
			if (rs.next()) {
				System.out.println("1: First Name = " + rs.getString(2));
				System.out.println("2: Last Name = " + rs.getString(3));
				System.out.println("3: Department Code = " + rs.getString(6));
				System.out.println("4: Grade = " + rs.getString(7));
				System.out.println("5: Designation = " + rs.getString(8));
				System.out.println("6: Basic Salary = " + rs.getLong(9));
				System.out.println("7: Marital Status = " + rs.getString(11));
				System.out.println("8: Home Address = " + rs.getString(12));
				System.out.println("9: Contact Number = " + rs.getString(13));
				System.out.println();
			}
			else {
				System.out.println("Invalid Employee Id");
				return 0;
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return 1;
	}

	@Override
	public void displayEmployee() throws SQLException, EMSProblemException{
		conn = DBUtil.establishConnection();
		Statement stmt = conn.createStatement();
		ResultSet rs = stmt.executeQuery(IQueryMapper.VIEW_EMPLOYEE);	
		while(rs.next()){
			System.out.println(rs.getString(1));
			System.out.println(rs.getString(2));
			System.out.println(rs.getString(3));
			System.out.println("******************");
			System.out.println();
		}
	}
	@Override
	public int modifyDetails(int option, String data, String id)
			throws EMSProblemException {
		try {
			conn = DBUtil.establishConnection();
			switch (option) {
			case 1:
				PreparedStatement preparedStatement1 = conn
						.prepareStatement(IQueryMapper.UPDATE_FNAME);
				preparedStatement1.setString(1, data);
				preparedStatement1.setString(2, id);
				preparedStatement1.executeUpdate();
				PreparedStatement psmtfname = conn
						.prepareStatement(IQueryMapper.FIND_EMPLOYEE);
				psmtfname.setString(1, id);
				ResultSet rs1 = psmtfname.executeQuery();
				while (rs1.next()) {
					System.out.println("Employee id " + rs1.getString(1)
							+ ", First name = " + rs1.getString(2));
				}
				break;

			case 2:
				PreparedStatement preparedStatement2 = conn
						.prepareStatement(IQueryMapper.UPDATE_LNAME);
				preparedStatement2.setString(1, data);
				preparedStatement2.setString(2, id);
				preparedStatement2.executeUpdate();
				PreparedStatement psmtlname = conn
						.prepareStatement(IQueryMapper.FIND_EMPLOYEE);
				psmtlname.setString(1, id);
				ResultSet rs2 = psmtlname.executeQuery();
				while (rs2.next()) {
					System.out.println("Employee id " + rs2.getString(1)
							+ ", Last name = " + rs2.getString(3));
				}
				break;

			case 3:
				PreparedStatement preparedStatement3 = conn
						.prepareStatement(IQueryMapper.UPDATE_DCODE);
				preparedStatement3.setString(1, data);
				preparedStatement3.setString(2, id);
				preparedStatement3.executeUpdate();
				PreparedStatement psmtdcode = conn
						.prepareStatement(IQueryMapper.FIND_EMPLOYEE);
				psmtdcode.setString(1, id);
				ResultSet rs3 = psmtdcode.executeQuery();
				while (rs3.next()) {
					System.out.println("Employee id " + rs3.getString(1)
							+ ", Department Code = " + rs3.getString(6));
				}
				break;

			case 4:
				emsServ = new EMSAdminServiceImpl();
				check = emsServ.validateGrade(data);
				if (check == 0) {
					return check;
				}
				PreparedStatement preparedStatement4 = conn
						.prepareStatement(IQueryMapper.UPDATE_GRADE);
				preparedStatement4.setString(1, data);
				preparedStatement4.setString(2, id);
				preparedStatement4.executeUpdate();
				PreparedStatement psmtgrade = conn
						.prepareStatement(IQueryMapper.FIND_EMPLOYEE);
				psmtgrade.setString(1, id);
				ResultSet rs4 = psmtgrade.executeQuery();
				while (rs4.next()) {
					System.out.println("Employee id " + rs4.getString(1)
							+ ", Grade = " + rs4.getString(7));
				}
				break;

			case 5:
				PreparedStatement preparedStatement5 = conn
						.prepareStatement(IQueryMapper.UPDATE_DESIGNATION);
				preparedStatement5.setString(1, data);
				preparedStatement5.setString(2, id);
				preparedStatement5.executeUpdate();
				PreparedStatement psmtdesgn = conn
						.prepareStatement(IQueryMapper.FIND_EMPLOYEE);
				psmtdesgn.setString(1, id);
				ResultSet rs5 = psmtdesgn.executeQuery();
				while (rs5.next()) {
					System.out.println("Employee id " + rs5.getString(1)
							+ ", Designation = " + rs5.getString(8));
				}
				break;

			case 6:
				emsServ = new EMSAdminServiceImpl();
				Long sal = Long.valueOf(data);
				PreparedStatement test = conn
						.prepareStatement(IQueryMapper.GET_GRADE);
				test.setString(1, id);
				ResultSet rstest = test.executeQuery();
				if (rstest.next()) {
					String testGrade = rstest.getString("emp_grade");
					long sal1 = sal.longValue();
					check = emsServ.validateSalary(sal1, testGrade);
					if (check == 0) {
						return check;
					}

				}
				PreparedStatement preparedStatement6 = conn
						.prepareStatement(IQueryMapper.UPDATE_SALARY);
				preparedStatement6.setString(1, data);
				preparedStatement6.setString(2, id);
				preparedStatement6.executeUpdate();
				PreparedStatement psmtsalary = conn
						.prepareStatement(IQueryMapper.FIND_EMPLOYEE);
				psmtsalary.setString(1, id);
				ResultSet rs6 = psmtsalary.executeQuery();
				while (rs6.next()) {
					System.out.println("Employee id " + rs6.getString(1)
							+ ", Basic Salary = " + rs6.getString(9));
				}
				break;

			case 7:
				emsServ = new EMSAdminServiceImpl();
				check = emsServ.validateStatus(data);
				if (check == 1) {
					check = 0;
					return check;
				}
				PreparedStatement preparedStatement7 = conn
						.prepareStatement(IQueryMapper.UPDATE_STATUS);
				preparedStatement7.setString(1, data);
				preparedStatement7.setString(2, id);
				preparedStatement7.executeUpdate();
				PreparedStatement psmtstatus = conn
						.prepareStatement(IQueryMapper.FIND_EMPLOYEE);
				psmtstatus.setString(1, id);
				ResultSet rs7 = psmtstatus.executeQuery();
				while (rs7.next()) {
					System.out.println("Employee id " + rs7.getString(1)
							+ ", Marital Status = " + rs7.getString(11));
				}
				break;

			case 8:
				PreparedStatement preparedStatement8 = conn
						.prepareStatement(IQueryMapper.UPDATE_ADDRESS);
				preparedStatement8.setString(1, data);
				preparedStatement8.setString(2, id);
				preparedStatement8.executeUpdate();
				PreparedStatement psmtaddress = conn
						.prepareStatement(IQueryMapper.FIND_EMPLOYEE);
				psmtaddress.setString(1, id);
				ResultSet rs8 = psmtaddress.executeQuery();
				while (rs8.next()) {
					System.out.println("Employee id " + rs8.getString(1)
							+ ", Address = " + rs8.getString(12));
				}
				break;

			case 9:
				PreparedStatement preparedStatement9 = conn
						.prepareStatement(IQueryMapper.UPDATE_NUM);
				preparedStatement9.setString(1, data);
				preparedStatement9.setString(2, id);
				preparedStatement9.executeUpdate();
				PreparedStatement psmtnum = conn
						.prepareStatement(IQueryMapper.FIND_EMPLOYEE);
				psmtnum.setString(1, id);
				ResultSet rs9 = psmtnum.executeQuery();
				while (rs9.next()) {
					System.out.println("Employee id " + rs9.getString(1)
							+ ", Contact Number = " + rs9.getString(13));
				}
				break;

			default:
				System.out.println("Invalid Option");
				System.exit(0);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return option;

	}

}
