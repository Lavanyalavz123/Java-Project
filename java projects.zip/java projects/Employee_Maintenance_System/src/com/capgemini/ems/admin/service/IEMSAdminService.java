package com.capgemini.ems.admin.service;


import java.sql.SQLException;

import com.capgemini.ems.bean.DepartmentBean;
import com.capgemini.ems.bean.EmployeeBean;
import com.capgemini.ems.bean.UserMasterBean;
import com.capgemini.ems.exception.EMSProblemException;

public interface IEMSAdminService {
	public abstract boolean addEmployeeDetails(EmployeeBean empbean, UserMasterBean userbean, DepartmentBean deptbean)throws EMSProblemException;
	public abstract int checkLogin(String username, String password)throws EMSProblemException;
	public abstract int viewEmployeeDetails() throws EMSProblemException;
	public abstract int validateSalary(long basic, String grade) throws EMSProblemException;
	public abstract int validateDob(String dob) throws EMSProblemException;
	public abstract int validateDoj(String dob,String doj) throws EMSProblemException;
	public abstract int validateUserType(String usertype) throws EMSProblemException;
	public abstract int validateDepartment(String dname) throws EMSProblemException;
	public abstract int validateGrade(String grade) throws EMSProblemException;
	public abstract int validateGender(String gender) throws EMSProblemException;
	public abstract int validateStatus(String status) throws EMSProblemException;
	public abstract void changePassword(String uname, String password) throws EMSProblemException, SQLException;
}
