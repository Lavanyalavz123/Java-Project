package com.capgemini.ems.admin.dao;

import java.sql.SQLException;

import com.capgemini.ems.exception.EMSProblemException;

public interface IEMSAdminModifyDAO {
	public abstract int findEmployeeById(String id) throws EMSProblemException;
	public abstract int modifyDetails(int option,String data,String id) throws EMSProblemException;
	public abstract void displayEmployee() throws SQLException, EMSProblemException;
}
