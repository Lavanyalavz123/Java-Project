package com.capgemini.ems.admin.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.capgemini.ems.bean.DepartmentBean;
import com.capgemini.ems.bean.EmployeeBean;
import com.capgemini.ems.bean.UserMasterBean;
import com.capgemini.ems.exception.EMSProblemException;
import com.capgemini.ems.util.DBUtil;

public class EMSAdminDAOImpl implements IEMSAdminDAO {
	private Connection conn = null;
	/*adds the employee details entered by the admin
	 */
	@Override
	public boolean addEmployeeDetails(EmployeeBean empbean,
			UserMasterBean userbean, DepartmentBean deptbean)
			throws EMSProblemException {
		boolean status = false;
		try {
			conn = DBUtil.establishConnection();
			PreparedStatement psmt1 = conn
					.prepareStatement(IQueryMapper.INSERT_DEPT_CODE);
			psmt1.setString(1, deptbean.getDept_name());
			ResultSet rs1 = psmt1.executeQuery();
			while (rs1.next()) {
				empbean.setDept_id(rs1.getInt(1));
			}

			PreparedStatement preparedStatement = conn
					.prepareStatement(IQueryMapper.INSERT_Employee);
			preparedStatement.setString(1, empbean.getEmp_first_name());
			preparedStatement.setString(2, empbean.getEmp_last_name());
			preparedStatement.setDate(3, empbean.getEmp_date_of_birth());
			preparedStatement.setDate(4, empbean.getEmp_date_of_joining());
			preparedStatement.setInt(5, empbean.getDept_id());
			preparedStatement.setString(6, empbean.getGrade_code());
			preparedStatement.setString(7, empbean.getEmp_designation());
			preparedStatement.setLong(8, empbean.getEmp_basic());
			preparedStatement.setString(9, empbean.getGender());
			preparedStatement.setString(10, empbean.getEmp_marital_status());
			preparedStatement.setString(11, empbean.getEmp_home_address());
			preparedStatement.setString(12, empbean.getEmp_contact_num());
			preparedStatement.setString(13, empbean.getMgr_id());

			int storedStatus = preparedStatement.executeUpdate();
			PreparedStatement psmtuser = conn
					.prepareStatement(IQueryMapper.INSERT_User);
			psmtuser.setString(1, userbean.getUserName());
			//psmtuser.setString(2, userbean.getUserPassword());
			psmtuser.setString(2, userbean.getUserType().toUpperCase());

			int storedStatusUser = psmtuser.executeUpdate();
			
			PreparedStatement psmtleave = conn
					.prepareStatement(IQueryMapper.INSERT_Leave);
			int storedLeave = psmtleave.executeUpdate();
			if ((storedStatus == 1) && (storedStatusUser == 1)&& (storedLeave == 1)) {

				status = true;
			}
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(IQueryMapper.VIEW_SEQ);
			while (rs.next()) {
				empbean.setEmp_id(rs.getString(1));
				userbean.setUserId(rs.getString(1));
			}
		} catch (SQLException e) {
			throw new EMSProblemException("problem : " + e.getMessage());
		}
		return status;
	}

	@Override
	public int checkLogin(String username, String password)
			throws EMSProblemException {
		int type = 0;
		try {
			conn = DBUtil.establishConnection();
			PreparedStatement preparedStatement = conn
					.prepareStatement(IQueryMapper.LoginCheck);
			preparedStatement.setString(1, username);
			preparedStatement.setString(2, password);
			ResultSet rs = preparedStatement.executeQuery();

			if (rs.next()) {
				if (rs.getString("userType").equals("Admin")) {
					type = 1;
				} else
					type = 2;
				System.out.println(rs.getString("userType")
						+ " Successfully logged in");
			} else {
				System.out.println("Wrong username or password");
				type = 3;
			}
		} catch (SQLException e) {
			throw new EMSProblemException("problem : " + e.getMessage());
		}
		//System.out.println(type);
		return type;

	}

	@Override
	public int viewEmployeeDetails() throws EMSProblemException {
		// HashSet<EmployeeBean> emplist = new HashSet<>();
		try {
			conn = DBUtil.establishConnection();
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(IQueryMapper.VIEW_EMPLOYEE);
			EmployeeBean employee = new EmployeeBean();
			while (rs.next()) {
				employee.setEmp_id(rs.getString(1));
				employee.setEmp_first_name(rs.getString(2));
				employee.setEmp_last_name(rs.getString(3));
				employee.setEmp_date_of_birth(rs.getDate(4));
				employee.setEmp_date_of_joining(rs.getDate(5));
				employee.setDept_id(rs.getInt(6));
				employee.setGrade_code(rs.getString(7));
				employee.setEmp_designation(rs.getString(8));
				employee.setEmp_basic(rs.getInt(9));
				employee.setGender(rs.getString(10));
				employee.setEmp_marital_status(rs.getString(11));
				employee.setEmp_home_address(rs.getString(12));
				employee.setEmp_contact_num(rs.getString(13));
				employee.setMgr_id(rs.getString(14));
				System.out.println(employee.toString());
				// emplist.add(employee);
				// emplist.forEach(System.out::println);
			}
		} catch (SQLException e) {
			throw new EMSProblemException("problem : " + e.getMessage());
		}
		return 0;
	}

	@Override
	public int validateSalary(long basic, String grade)
			throws EMSProblemException {
		int status = 0;
		try {
			conn = DBUtil.establishConnection();
			PreparedStatement preparedStatement = conn
					.prepareStatement(IQueryMapper.VALIDATE_GRADE);
			preparedStatement.setString(1, grade.toUpperCase());
			ResultSet rs = preparedStatement.executeQuery();
			if (rs.next()) {
				System.out.println("Salary should be greater than "+rs.getLong("min_salary")+ " and less than "+ rs.getLong("max_salary") );
				if ((rs.getLong("min_salary") < basic)
						&& (rs.getLong("max_salary") > basic)) {
					status = 1;
				} else {
					status = 0;
				}
			} else {
				System.out.println("Invalid Grade");
			}

		} catch (SQLException e) {
			throw new EMSProblemException("problem : " + e.getMessage());
		}
		if (status == 0){
			System.out.println("Basic Salary out of Salary Band");
		}
		return status;
	}

	@Override
	public void changePassword(String uname, String password) throws EMSProblemException,
			SQLException {
		conn = DBUtil.establishConnection();
		PreparedStatement preparedStatement = conn
				.prepareStatement(IQueryMapper.CHANGE_PASSWORD);
		preparedStatement.setString(1, password);
		preparedStatement.setString(2, uname);
		preparedStatement.executeQuery();
	}

	

	/*
	 * public static void main(String[] args) throws EMSProblemException {
	 * EMSAdminDAOImpl test = new EMSAdminDAOImpl();
	 * test.findEmployeeById("100000"); }
	 */

}
