package com.capgemini.ems.admin.dao;

public interface IQueryMapper {
	public static final String CHANGE_PASSWORD="UPDATE user_master SET userpassword = ? where username=?";
	public static final String INSERT_Employee="INSERT INTO Employee values(user_seq.NEXTVAL,?,?,?,?,?,?,?,?,?,?,?,?,?)";
	public static final String INSERT_DEPT_CODE="Select dept_id from department where dept_name =?";
	public static final String INSERT_User="INSERT INTO User_Master values(user_seq.CURRVAL,?,'userpwd',?)";
	public static final String VIEW_SEQ="SELECT user_seq.currval from dual";
	public static final String INSERT_Leave="INSERT INTO leave_history values(leave_seq.nextval,user_seq.currval,12,null,null,null,null,null)";
	public static final String LoginCheck="SELECT username, userpassword, usertype from user_master where username=? and userpassword=?";
	public static final String VIEW_EMPLOYEE="SELECT * FROM Employee";
	public static final String VALIDATE_GRADE="SELECT min_salary, max_salary from grade_master where grade_code=?";
	public static final String FIND_EMPLOYEE="SELECT * FROM Employee where emp_id = ?";
	public static final String UPDATE_FNAME="UPDATE employee SET emp_first_name = ? where emp_id=?";
	public static final String UPDATE_LNAME="UPDATE employee SET emp_last_name = ? where emp_id=?";
	public static final String UPDATE_DCODE="UPDATE employee SET emp_dept_id = ? where emp_id=?";
	public static final String UPDATE_GRADE="UPDATE employee SET emp_grade = ? where emp_id=?";
	public static final String UPDATE_DESIGNATION="UPDATE employee SET emp_designation = ? where emp_id=?";
	public static final String UPDATE_SALARY="UPDATE employee SET emp_basic = ? where emp_id=?";
	public static final String UPDATE_STATUS="UPDATE employee SET emp_marital_status = ? where emp_id=?";
	public static final String UPDATE_ADDRESS="UPDATE employee SET emp_home_address = ? where emp_id=?";
	public static final String UPDATE_NUM="UPDATE employee SET emp_contact_num = ? where emp_id=?";
	public static final String GET_GRADE="SELECT emp_grade from employee where emp_id=?";
	
}
