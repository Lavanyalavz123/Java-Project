package com.capgemini.ems.admin.ui;

import java.sql.Date;
import java.time.format.DateTimeParseException;
import java.util.InputMismatchException;
import java.util.Scanner;

import com.capgemini.ems.admin.service.EMSAdminServiceImpl;
import com.capgemini.ems.admin.service.IEMSAdminService;
import com.capgemini.ems.bean.DepartmentBean;
import com.capgemini.ems.bean.EmployeeBean;
import com.capgemini.ems.bean.UserMasterBean;
import com.capgemini.ems.exception.EMSProblemException;

public class UIAddEmployee {
	EmployeeBean empbean = new EmployeeBean();
	UserMasterBean userbean = new UserMasterBean();
	DepartmentBean deptbean = new DepartmentBean();
	Scanner scanner = new Scanner(System.in);

	public void addEmpMain() throws EMSProblemException,
			DateTimeParseException, NullPointerException,
			IllegalArgumentException {
		String usertype = null, birth = null, dname = null, grade = null, desgn = null;
		String gender = null, status = null, join = null;
		Date dob = null, doj = null;
		int test = 0, check = 0, age = 0;
		long basic = 0;

		while (check == 0) {
			System.out.println("Enter User Type (User/Admin)");
			usertype = scanner.next();
			check = validateUserType(usertype);
		}

		System.out.println("Enter Employee First Name ");
		String fname = scanner.next();

		System.out.println("Enter Employee Last Name ");
		String lname = scanner.next();
		while (check == 1) {
			System.out.println("Enter Employee Date of Birth (yyyy-mm-dd)");
			birth = scanner.next();
			age = validateDob(birth);
			if (age < 0) {
				System.out.println("Enter a valid date ");
			} else if (age < 18) {
				System.out.println("Candidate is underage");
			} else if (age > 58) {
				System.out.println("Age should not be greater than 58");
			} else {
				dob = Date.valueOf(birth);
				check = 0;
			}
		}

		while (check == 0) {
			System.out.println("Enter Employee Date of Joining (yyyy-mm-dd)");
			join = scanner.next();
			test = validateDoj(birth, join);
			if (age < 0) {
				System.out.println("Enter a valid date ");
			} else if (test > 0) {
				System.out.println("Invalid Date of Joining");
				System.out.println("Date of joining should be after Date of Birth");
				check = 0;
			} else {
				doj = Date.valueOf(join);
				check = 1;
			}
		}

		while (check == 1) {
			System.out
					.println("Enter Employee Department Name (Electronics, Mechanics, IT) ");
			dname = scanner.next();
			check = validateDepartment(dname);
		}

		while (check == 0) {
			System.out.println("Enter Employee Grade (M1 / M2 / M3 / M4 / M5 / M6 / M7)");
			grade = scanner.next();
			check = validateGrade(grade);
		}

		System.out.println("Enter Designation");
		desgn = scanner.next();
		// check = validateDesignation(desgn);

		while (check == 1) {
			System.out.println("Enter Employee Basic Salary ");
			try{
				basic = scanner.nextLong();
			}catch(InputMismatchException e){
				System.out.println("Please enter a numerical value");
			}
			int validate = validateSalary(basic, grade);
			if (validate == 0) {
				// System.out.println("Basic Salary out of Salary Band");
				check = 1;
			} else
				check = 0;
		}

		while (check == 0) {
			System.out.println("Enter Employee Gender ");
			gender = scanner.next();
			check = validateGender(gender);
		}

		while (check == 1) {
			System.out.println("Enter Maritial Status ");
			status = scanner.next();
			check = validateStatus(status);
		}

		System.out.println("Enter Employee Address ");
		String address = scanner.next();

		System.out.println("Enter Contact Number ");
		String num = scanner.next();

		System.out.println("Enter Manager Id ");
		String mid = scanner.next();

		System.out.println("Generate Username ");
		String user = scanner.next();

		/*System.out.println("Generate Password");
		String pwd = scanner.next();*/

		userbean.setUserType(usertype);
		empbean.setEmp_first_name(fname);
		empbean.setEmp_last_name(lname);
		empbean.setEmp_date_of_birth(dob);
		empbean.setEmp_date_of_joining(doj);
		deptbean.setDept_name(dname);
		empbean.setGrade_code(grade);
		empbean.setEmp_designation(desgn);
		empbean.setEmp_basic(basic);
		empbean.setGender(gender);
		empbean.setEmp_marital_status(status);
		empbean.setEmp_home_address(address);
		empbean.setEmp_contact_num(num);
		empbean.setMgr_id(mid);
		userbean.setUserName(user);
		//userbean.setUserPassword(pwd);
		try {
			boolean flag = new UIAddEmployee().addEmployee(empbean, userbean,
					deptbean);
			if (flag == true) {
				System.out.println("Insertion Successful for "
						+ empbean.getEmp_id() + " "
						+ empbean.getEmp_first_name() + " "
						+ empbean.getEmp_last_name());
			}

		} catch (EMSProblemException e) {
			System.out.println("exception: " + e);
		}
	}

	IEMSAdminService emsServ = null;

	public boolean addEmployee(EmployeeBean empbean, UserMasterBean userbean,
			DepartmentBean deptbean) throws EMSProblemException {
		emsServ = new EMSAdminServiceImpl();
		return emsServ.addEmployeeDetails(empbean, userbean, deptbean);
	}

	public int validateUserType(String usertype) throws EMSProblemException {
		emsServ = new EMSAdminServiceImpl();
		return emsServ.validateUserType(usertype);
	}

	public int validateDepartment(String dname) throws EMSProblemException {
		emsServ = new EMSAdminServiceImpl();
		return emsServ.validateDepartment(dname);
	}

	public int validateGrade(String grade) throws EMSProblemException {
		emsServ = new EMSAdminServiceImpl();
		return emsServ.validateGrade(grade);
	}

	/*
	 * public int validateDesignation(String desgn) throws EMSProblemException{
	 * emsServ = new EMSAdminServiceImpl(); return
	 * emsServ.validateDesignation(desgn); }
	 */

	public int validateSalary(long basic, String grade)
			throws EMSProblemException {
		emsServ = new EMSAdminServiceImpl();
		return emsServ.validateSalary(basic, grade);
	}

	public int validateDob(String dob) throws EMSProblemException,
			DateTimeParseException, NullPointerException {
		emsServ = new EMSAdminServiceImpl();
		return emsServ.validateDob(dob);
	}

	public int validateDoj(String dob, String doj) throws EMSProblemException,
			NullPointerException {
		emsServ = new EMSAdminServiceImpl();
		return emsServ.validateDoj(dob, doj);
	}

	public int validateGender(String gender) throws EMSProblemException {
		emsServ = new EMSAdminServiceImpl();
		return emsServ.validateGender(gender);
	}

	public int validateStatus(String status) throws EMSProblemException {
		emsServ = new EMSAdminServiceImpl();
		return emsServ.validateStatus(status);
	}
}
