package com.capgemini.ems.admin.service;

import java.sql.SQLException;

import com.capgemini.ems.admin.dao.EMSAdminModifyDAOImpl;
import com.capgemini.ems.admin.dao.IEMSAdminModifyDAO;
import com.capgemini.ems.exception.EMSProblemException;

public class EMSAdminModifyServiceImpl implements IEMSAdminModifyService {
	IEMSAdminModifyDAO emsDao=null;
	@Override
	public int findEmployeeById(String id) throws EMSProblemException {
		emsDao=new EMSAdminModifyDAOImpl();
		return emsDao.findEmployeeById(id);
	}
	@Override
	public int modifyDetails(int option, String data,String id) throws EMSProblemException {
		emsDao=new EMSAdminModifyDAOImpl();
		return emsDao.modifyDetails(option, data, id);
	}
	@Override
	public void displayEmployee() throws EMSProblemException, SQLException{
		emsDao=new EMSAdminModifyDAOImpl();
		emsDao.displayEmployee();
		
	}

}
