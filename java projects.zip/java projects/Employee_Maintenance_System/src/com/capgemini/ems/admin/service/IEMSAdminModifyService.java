package com.capgemini.ems.admin.service;

import java.sql.SQLException;

import com.capgemini.ems.exception.EMSProblemException;

public interface IEMSAdminModifyService {
	public abstract int findEmployeeById(String id) throws EMSProblemException;
	public abstract int modifyDetails(int option,String data,String id) throws EMSProblemException;
	public abstract void displayEmployee() throws EMSProblemException, SQLException;
}
