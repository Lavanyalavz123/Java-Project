package com.capgemini.ems.admin.ui;

import java.sql.SQLException;
import java.util.Scanner;

import com.capgemini.ems.admin.service.EMSAdminModifyServiceImpl;
import com.capgemini.ems.admin.service.IEMSAdminModifyService;
import com.capgemini.ems.bean.EmployeeBean;
import com.capgemini.ems.exception.EMSProblemException;

public class UIModifyEmployee {
	EmployeeBean empbean = new EmployeeBean();
	Scanner scanner = new Scanner(System.in);
	String id;

	public void modifyEmployee() throws EMSProblemException, SQLException {

		int check = 0;
		while(check == 0){
		displayEmployee();
		System.out.println("Enter the Employee Id");
		id = scanner.next();
		check = findEmployeeById(id);
		}
		System.out.println("Enter the field code which you want to edit");
		int option = scanner.nextInt();
		check = 0;
		while (check == 0) {
			System.out.println("Enter the data to be updated");
			String data = scanner.next();
			check = modifyDetails(option, data, id);
		}
	}
	IEMSAdminModifyService emsServ = null;
	
	private void displayEmployee() throws EMSProblemException, SQLException {
		emsServ = new EMSAdminModifyServiceImpl();
		emsServ.displayEmployee();
	}

	private int findEmployeeById(String id) throws EMSProblemException {
		emsServ = new EMSAdminModifyServiceImpl();
		return emsServ.findEmployeeById(id);
	}

	private int modifyDetails(int option, String data, String id)
			throws EMSProblemException {
		emsServ = new EMSAdminModifyServiceImpl();
		return emsServ.modifyDetails(option, data, id);
	}
}
