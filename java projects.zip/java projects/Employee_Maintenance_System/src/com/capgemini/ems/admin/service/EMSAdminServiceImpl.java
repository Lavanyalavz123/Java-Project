package com.capgemini.ems.admin.service;

import java.sql.SQLException;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeParseException;

import com.capgemini.ems.admin.dao.EMSAdminDAOImpl;
import com.capgemini.ems.admin.dao.IEMSAdminDAO;
import com.capgemini.ems.bean.DepartmentBean;
import com.capgemini.ems.bean.EmployeeBean;
import com.capgemini.ems.bean.UserMasterBean;
import com.capgemini.ems.exception.EMSProblemException;

public class EMSAdminServiceImpl implements IEMSAdminService {
	IEMSAdminDAO emsDao = null;
	int check = 1, test = 1;
	Period p = null;

	// LocalDate today, dateOfBirth;

	@Override
	public boolean addEmployeeDetails(EmployeeBean empbean,
			UserMasterBean userbean, DepartmentBean deptbean)
			throws EMSProblemException {
		emsDao = new EMSAdminDAOImpl();
		return emsDao.addEmployeeDetails(empbean, userbean, deptbean);
	}

	@Override
	public int checkLogin(String username, String password)
			throws EMSProblemException {
		emsDao = new EMSAdminDAOImpl();
		return emsDao.checkLogin(username, password);
	}

	@Override
	public int viewEmployeeDetails() throws EMSProblemException {
		emsDao = new EMSAdminDAOImpl();
		return emsDao.viewEmployeeDetails();
	}

	@Override
	public int validateSalary(long basic, String grade)
			throws EMSProblemException {
		emsDao = new EMSAdminDAOImpl();
		return emsDao.validateSalary(basic, grade);
	}

	@Override
	public int validateDob(String dob) throws EMSProblemException,
			NullPointerException {
		try {
			LocalDate today = LocalDate.now();
			LocalDate dateOfBirth = LocalDate.parse(dob);
			p = Period.between(dateOfBirth, today);
		} catch (IllegalArgumentException e) {
			System.out.println("You have entered an invalid format");
		} catch (DateTimeParseException e) {
			System.out.println("You have entered an invalid format");
		}
		if (p == null) {
			return -1;
		}
		return p.getYears();
	}

	@Override
	public int validateDoj(String dob, String doj) throws EMSProblemException,
			NullPointerException {
		try {
			LocalDate dateOfBirth = LocalDate.parse(dob);
			LocalDate dateOfJoining = LocalDate.parse(doj);
			test = dateOfBirth.compareTo(dateOfJoining);
		} catch (IllegalArgumentException e) {
			System.out.println("You have entered an invalid format");
		} catch (DateTimeParseException e) {
			System.out.println("You have entered an invalid format");
		}
		// System.out.println(test);
		if (test == 1) {
			return -1;
		}
		return test;
	}

	@Override
	public int validateUserType(String usertype) throws EMSProblemException {

		if (!(usertype.equalsIgnoreCase("Admin") || usertype
				.equalsIgnoreCase("User"))) {
			System.out.println("Invalid User Type");
			check = 0;
		}
		return check;
	}

	@Override
	public int validateDepartment(String dname) throws EMSProblemException {
		if (!(dname.equalsIgnoreCase("Electronics")
				|| dname.equalsIgnoreCase("Mechanics") || dname
					.equalsIgnoreCase("IT"))) {
			System.out.println("Invalid Department Name");
			check = 1;
		} else {
			check = 0;
		}

		return check;
	}

	@Override
	public int validateGrade(String grade) throws EMSProblemException {
		if (!(grade.equalsIgnoreCase("M1") || grade.equalsIgnoreCase("M2")
				|| grade.equalsIgnoreCase("M3") || grade.equalsIgnoreCase("M4")
				|| grade.equalsIgnoreCase("M5") || grade.equalsIgnoreCase("M6") || grade
					.equalsIgnoreCase("M7"))) {
			System.out.println("Invalid Grade Code");
			check = 0;
		} else {
			check = 1;
		}

		return check;
	}

	@Override
	public int validateGender(String gender) throws EMSProblemException {
		if (!((gender.equalsIgnoreCase("Female") || (gender
				.equalsIgnoreCase("Male"))))) {
			System.out.println("Invalid Gender");
			check = 0;
		} else
			check = 1;
		return check;
	}

	@Override
	public int validateStatus(String status) throws EMSProblemException {
		if (!(status.equalsIgnoreCase("Single")
				|| status.equalsIgnoreCase("Married")
				|| status.equalsIgnoreCase("Divorced")
				|| status.equalsIgnoreCase("Separated") || status
					.equalsIgnoreCase("Widowed"))) {
			System.out.println("Invalid Maritial Status");
			check = 1;
		} else
			check = 0;
		return check;
	}

	@Override
	public void changePassword(String uname, String password)
			throws EMSProblemException, SQLException {
		emsDao = new EMSAdminDAOImpl();
		emsDao.changePassword(uname, password);
	}

	/*
	 * @Override public int validateDesignation(String desgn) throws
	 * EMSProblemException { // TODO Auto-generated method stub return 0; }
	 */
	/*
	 * public static void main(String[] args) throws EMSProblemException {
	 * EMSServiceImpl test = new EMSServiceImpl();
	 * test.validateDoj("1996-04-28","1996-04-27"); }
	 */
}
