package com.capg.uas.exception;

public class AdmissionException extends Exception{ 
	/************************************************
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public AdmissionException(String message) {
		super(message);
	}
	public AdmissionException(){
		
		
		
		
	}
}

	
