package com.capg.uas.service;

import java.sql.Date;
import java.util.ArrayList;

import com.capg.uas.bean.ApplicationBean;
import com.capg.uas.bean.Programs_OfferedBean;
import com.capg.uas.bean.Programs_ScheduledBean;
import com.capg.uas.bean.ParticipantsBean;
import com.capg.uas.exception.AdmissionException;

public interface IUASService {
	//public abstract void viewAllPrograms() throws AdmissionException;
	public abstract ArrayList<Programs_ScheduledBean> viewAllPrograms() throws AdmissionException;
	public abstract int applyForScheduledProgram(ApplicationBean application) throws AdmissionException;
	public abstract String viewApplicationStatus(int Application_Id)  throws AdmissionException;
	public abstract int checkLogin(String login_id,String password)throws AdmissionException;
	public abstract ArrayList<ApplicationBean> viewApplications(String ProgramName) throws AdmissionException;
	public abstract ApplicationBean decidingApplicationStatus(ApplicationBean app4) throws AdmissionException;
	public abstract int managingProgramsOffered(Programs_OfferedBean program1) throws  AdmissionException;
	public abstract int deleteProgramsOffered(String  ProgramName) throws  AdmissionException;
	public abstract int managingScheduledPrograms(Programs_ScheduledBean program) throws AdmissionException;
	
	public abstract ArrayList<Programs_ScheduledBean> viewListofProgramsScheduled(Date start_date,Date end_date ) throws AdmissionException;
	public abstract ApplicationBean updateinterviewStatus( int application_id) throws AdmissionException;
	public abstract ArrayList<ApplicationBean> viewListofApplicants(String ProgramName) throws  AdmissionException;
	public abstract int deleteScheduledPrograms(String  ProgramName) throws  AdmissionException;
	
	
	
	public abstract boolean isValidName(String name) ;
	public abstract boolean isvalidmarks(String marksString);
	public abstract boolean isValidDate(String birth);
	public abstract boolean isValidGoal(String goals);
	public abstract boolean isValidMail(String email_id);
	public abstract boolean isValidDuration(String duration);
	public abstract boolean isValidDescp(String descp);
	public abstract boolean isValidEligibility(String eligibility);
	public abstract boolean isValidLocation(String location);
	public abstract boolean isValidSession(String sessionsString);
	
}

