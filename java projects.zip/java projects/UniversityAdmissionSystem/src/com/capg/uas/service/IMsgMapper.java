package com.capg.uas.service;

public interface IMsgMapper {

	public static final String NAME_ERROR= "Name must contain only Alphabets";
	public static final String NAME_ERROR1="Date must be given in a specified format";
	public static final String NAME_ERROR2 = "Marks must be greater than 0 and less than 100";
	public static final String NAME_ERROR3 = "goals should only be characters not numbers";
	public static final String NAME_ERROR4="EmailID must be given in a specified format";
	public static final String NAME_ERROR5= "Description must contain only Alphabets";
	public static final String NAME_ERROR6= "Eligibility must contain only Alphabets";
	public static final String NAME_ERROR7 = "Duration must only contain numbers not alphabets";
	public static final String NAME_ERROR8 = "Location must only contain alphabets";
	public static final  String NAME_ERROR9 ="The number of sessions per week must be less than 10" ;
	public static final  String NAME_ERROR10 = "qualification must contain only Characters";
	public static final String NAME_ERROR12 = "Must contain only options from the list";
	
}
