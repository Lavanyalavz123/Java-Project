package com.capg.uas.service;

import java.sql.Date;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capg.uas.bean.ApplicationBean;
import com.capg.uas.bean.ParticipantsBean;
import com.capg.uas.bean.Programs_OfferedBean;
import com.capg.uas.bean.Programs_ScheduledBean;
import com.capg.uas.dao.IUASdao;
import com.capg.uas.dao.UASdaoImpl;
import com.capg.uas.exception.AdmissionException;


public class UASServiceImpl implements IUASService {

	//we are creating an object of dao in service layer and then calling the dao methods
	IUASdao uasDao=null;
	@Override
	public  ArrayList<Programs_ScheduledBean> viewAllPrograms() throws AdmissionException{
			
		uasDao=new UASdaoImpl();
		return uasDao.viewAllPrograms();
	}
	@Override
	public int applyForScheduledProgram(ApplicationBean application) throws AdmissionException {
		uasDao=new UASdaoImpl();
		return uasDao.applyForScheduledProgram(application);
		
	}
	@Override
	public String viewApplicationStatus(int Application_Id) throws AdmissionException {
		uasDao=new UASdaoImpl();
		return uasDao.viewApplicationStatus(Application_Id);
	}
	
	@Override		
	public int checkLogin(String login_id, String password)
			throws AdmissionException {
		uasDao=new UASdaoImpl();
		return uasDao.checkLogin(login_id, password);
	}
		
	
	
	@Override
	public ArrayList<ApplicationBean> viewApplications(String ProgramName) throws AdmissionException {
		uasDao=new UASdaoImpl();
		return uasDao.viewApplications(ProgramName);
	}

	@Override
	public  ApplicationBean decidingApplicationStatus(ApplicationBean app4)
			throws AdmissionException {
		
		uasDao=new UASdaoImpl();
		return uasDao.decidingApplicationStatus(app4);
		
	}
	@Override
	public int managingProgramsOffered(Programs_OfferedBean program1) throws AdmissionException {
		uasDao=new UASdaoImpl();
		return uasDao.managingProgramsOffered(program1);
	}
	
	
	
	@Override
	public int managingScheduledPrograms(Programs_ScheduledBean program) throws AdmissionException {
		uasDao=new UASdaoImpl();
	
		return uasDao.managingScheduledPrograms(program);
		
	}
	@Override
	public ArrayList<Programs_ScheduledBean> viewListofProgramsScheduled(Date start_date, Date end_date)
			throws AdmissionException {
		uasDao=new UASdaoImpl();
		return uasDao.viewListofProgramsScheduled(start_date,end_date);
		
	}
	@Override
	public ApplicationBean updateinterviewStatus(int application_id)
			throws AdmissionException {
		
		uasDao=new UASdaoImpl();
		return uasDao.updateinterviewStatus(application_id);
	}
	@Override
	public ArrayList<ApplicationBean> viewListofApplicants(String ProgramName) throws AdmissionException {
		
		uasDao=new UASdaoImpl();
		return uasDao.viewListofApplicants(ProgramName);
		
	}
	
	@Override
	public int deleteProgramsOffered(String ProgramName) throws AdmissionException {
		uasDao=new UASdaoImpl();
		return uasDao.deleteProgramsOffered(ProgramName);
		
		
	}
	@Override
	public int deleteScheduledPrograms(String ProgramName)
			throws AdmissionException {
	
		uasDao=new UASdaoImpl();
		return uasDao.deleteScheduledPrograms(ProgramName);
	}
	
//validation methods starts from here	
	@Override
	
		public boolean isValidName(String name) {
			Pattern pattern = Pattern.compile("[A-Za-z ]{2,}");
			Matcher matcher = pattern.matcher(name);

			return matcher.matches();

	}
	 @Override
	public boolean  isValidDate(String birth){
			  Pattern  pattern = Pattern.compile( "^[0-9]{4}-[0-9]{2}-[0-9]{2}$");
	          Matcher matcher = pattern.matcher(birth);
			 
			        return matcher.matches();
			    
			
}
	@Override
	public boolean isvalidmarks(String marksString) {
		
		Pattern pattern = Pattern.compile("[0-9]{2}|[1][0][0]");
		Matcher matcher = pattern.matcher(marksString);

		return matcher.matches();
		
		
	}
	@Override
	public boolean isValidGoal(String goals) {
		
		Pattern pattern = Pattern.compile("[A-Za-z]{3,15}");
		Matcher matcher = pattern.matcher(goals);

		return matcher.matches();

	}
	@Override
	public boolean isValidMail(String email_id) {

		Pattern pattern = Pattern.compile("^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$"); 
		Matcher matcher = pattern.matcher(email_id);

		return matcher.matches();
	}
	public boolean isValidDescp(String descp) {
          
		Pattern pattern = Pattern.compile("[A-Za-z ]{2,30}");
		Matcher matcher = pattern.matcher(descp);

		return matcher.matches();
		
		
	}
	public boolean isValidEligibility(String eligibility) {
		Pattern pattern = Pattern.compile("[A-Za-z]{2,40}");
		Matcher matcher = pattern.matcher(eligibility);

		return matcher.matches();
	}
	public boolean isValidDuration(String duration) {
		Pattern pattern = Pattern.compile("[0-9]{1,2}");
		Matcher matcher = pattern.matcher(duration);

		return matcher.matches();
		
	}
	public boolean isValidLocation(String location) {
		Pattern pattern = Pattern.compile("[A-Za-z]{2,40}");
		Matcher matcher = pattern.matcher(location);
		
		return matcher.matches();
	}
	public boolean isValidSession(String sessionsString) {
		Pattern pattern = Pattern.compile("[0-9]{1}");
		Matcher matcher = pattern.matcher(sessionsString);

		return matcher.matches();
	}
	public boolean isValidqualification(String qualification) {
		
		Pattern pattern = Pattern.compile("[A-Za-z]{2,5}");
		Matcher matcher = pattern.matcher(qualification);
		
		return matcher.matches();
	}
	public boolean isvalidSid(String sidString) {
		
		
		Pattern pattern = Pattern.compile("[1000|1001|1002|1003|1004|1005|1006]{4}");
		Matcher matcher = pattern.matcher(sidString);

		return matcher.matches();
	}
}

		
	

