package com.capg.uas.dao;

public interface IQueryMapper {
	
	public static final String INSERT_QUERY="INSERT INTO Application values(app1_id_seq.NEXTVAL,?,?,?,?,?,?,?,'Accepted',NULL)";
	//To auto generate the application id we use a sequence.
	public static final String VIEW_SEQ="SELECT app1_id_seq.currval from dual";
	//public static final String VIEW_SEQ1="SELECT pgm1_id_seq.currval from dual";
	
	public static final String VIEW_PROGRAM="SELECT  * from Programs_Scheduled";
	
	public static final String VIEW_STATUS="SELECT Status from Application where Application_id=?";
	
    public static final String LoginCheck="SELECT login_id, password, role from Users where login_id=? and password=?";
	//public static final String VIEW_APP="SELECT  * from Programs_Offered where ProgramName=?";
	
	public static final String VIEW_APP2="SELECT * FROM Application where "+
			 "Scheduled_program_id = (SELECT Scheduled_program_id from Programs_Offered where ProgramName=?)";
	
    public static final String VIEW_MARKS="SELECT marks_obtained from Application where Application_id=?";
    public static final String UPDATE_QUERY="UPDATE Application set Date_of_Interview=sysdate+7 where Application_id=?";
    public static final String VIEW_IDATE="SELECT sysdate+7 from dual";
    
    public static final String  INSERT_QUERY1="INSERT INTO Programs_Offered values(?,?,?,?,?,?)";
    public static final String  UPDATE_QUERY1="DELETE FROM Programs_Offered WHERE ProgramName=?";
    
    public static final String  INSERT_QUERY2="INSERT INTO Programs_Scheduled values(?,?,?,?,?,?)";
    public static final String  UPDATE_QUERY2="DELETE FROM Programs_Scheduled WHERE ProgramName=?";
    
    public static final String VIEW_SCHEDULE="SELECT * FROM Programs_Scheduled where start_date=? and end_date=?";
    
    public static final String  VIEW_MARKS1="SELECT marks_obtained from Application where Date_Of_Interview IS NOT NULL";
    public static final String VIEW_DETAILS="SELECT email_id, Scheduled_program_id fROM APPLICATION where application_id=?";
    
    public static final String VIEW_SEQ2="SELECT ROLL1_id_seq.currval from dual";
    public static final String INSERT_QUERY3="INSERT INTO PARTICIPANT values(ROLL1_id_seq.NEXTVAL,?,?,?)";
    
    public static final String VIEW_DETAILS1="SELECT status, marks_obtained from application where application_id = ?";
    public static final String UPDATE_STATUS="UPDATE Application set status=? where Application_id=?";
    
    public static final String VIEW_APP1="SELECT * from Programs_Offered where ProgramName=?";
 
}