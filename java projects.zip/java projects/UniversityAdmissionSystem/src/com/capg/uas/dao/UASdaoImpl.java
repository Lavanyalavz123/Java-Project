package com.capg.uas.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.capg.uas.bean.ApplicationBean;
import com.capg.uas.bean.ParticipantsBean;
import com.capg.uas.bean.Programs_OfferedBean;
import com.capg.uas.bean.Programs_ScheduledBean;
import com.capg.uas.exception.AdmissionException;
import com.capg.uas.util.DBUtil;

public class UASdaoImpl<PaticipantBean> implements IUASdao {
	private Connection conn = null;
	Programs_OfferedBean program1 = null;
	ApplicationBean application3 = new ApplicationBean();
	ApplicationBean application4 = null;
	ApplicationBean application5 = null;
	Programs_ScheduledBean program = null;
	ParticipantsBean participant = null;
	int n = 0, app_id = 0, schedule_id= 0;
	//String schedule_id = "";
	String email_id = null;

	/*
	 * This method is used to view all the programs scheduled by the university.
	 */
	
	@Override
	public  ArrayList<Programs_ScheduledBean> viewAllPrograms() throws AdmissionException {
		
		ArrayList<Programs_ScheduledBean> al2 = new ArrayList<Programs_ScheduledBean>();
		try {
			conn = DBUtil.establishConnection();
			PreparedStatement pstmt = conn.prepareStatement(IQueryMapper.VIEW_PROGRAM);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				Programs_ScheduledBean pgm = new Programs_ScheduledBean();

			int  Scheduled_program_id = rs.getInt(1);
			String	ProgramName = rs.getString(2);
			String Location=rs.getString(3);
			Date start_date=rs.getDate(4);
			Date end_date=rs.getDate(5);
			int sessions_per_week=rs.getInt(6);
			
		    
				pgm.setScheduled_program_id(Scheduled_program_id);
				pgm.setProgramName(ProgramName);
				pgm.setLocation(Location);
				pgm.setStart_date(start_date);
				pgm.setEnd_date(end_date);
				pgm.setSessions_per_week(sessions_per_week);
				
				al2.add(pgm);

			}

		} catch (SQLException e) {
			throw new AdmissionException(
					"Exception occured while viewing the list of  programs offered by the university : "
							+ e.getMessage());
		}

		return al2;
		
	}
	
	

	/*
	 * This method is used to apply for scheduled program by filling up the
	 * application details
	 */
	@Override
	public int applyForScheduledProgram(ApplicationBean application)
			throws AdmissionException {
		 int status=0;
		try {
			conn = DBUtil.establishConnection();
			PreparedStatement pstmt = conn.prepareStatement(IQueryMapper.INSERT_QUERY);

			pstmt.setString(1, application.getFull_name());
			pstmt.setDate(2, (Date) application.getDate_of_birth());
			pstmt.setString(3, application.getHighest_qualification());
			pstmt.setInt(4, application.getMarks_obtained());
			pstmt.setString(5, application.getGoals());
			pstmt.setString(6, application.getEmail_id());
			pstmt.setInt(7, application.getScheduled_program_id());
		    status=pstmt.executeUpdate();

			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(IQueryMapper.VIEW_SEQ);
			while (rs.next()) {
				application.setApplication_Id(rs.getInt(1));
			}

			

		} catch (SQLException e) {

			throw new AdmissionException(
					"problem occured while applying for program the scheduled : "
							+ e.getMessage());
		}
		return status;
	}

	/*
	 * this method is used to view the application status based on the id
	 * generated
	 */
	@Override
	public String viewApplicationStatus(int Application_Id)
			throws AdmissionException {
		String status1 = "";
		try {
			conn = DBUtil.establishConnection();
			PreparedStatement pstmt = conn
					.prepareStatement(IQueryMapper.VIEW_STATUS);
			pstmt.setInt(1, Application_Id);

			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				status1 = rs.getString(1);
			}

		} catch (SQLException e) {

			throw new AdmissionException(
					"exception occured while viewing status : "
							+ e.getMessage());
		}
		return status1;
	}

	/*
	 * this method is used to verify the login credentials for Administration
	 * and MAC members
	 */
	@Override
	public int checkLogin(String login_id, String password)
			throws AdmissionException {

		int type = 0;
		try {
			conn = DBUtil.establishConnection();
			PreparedStatement preparedStatement = conn.prepareStatement(IQueryMapper.LoginCheck);
			preparedStatement.setString(1, login_id);
			preparedStatement.setString(2, password);
			ResultSet rs = preparedStatement.executeQuery();

			if (rs.next()) {
				if (rs.getString("role").equals("MAC")) {
					type = 1;
				} else
					type = 2;
				System.out.println(rs.getString("role")
						+ " Successfully logged in");
			} else {
				System.out.println("Wrong username or password");
				type = 3;
			}
		} catch (SQLException e) {
			throw new AdmissionException("problem : " + e.getMessage());
		}
		return type;

	}

	/*
	 * this method is used to view the applications for a specific program.
	 */
	@Override
	public ArrayList <ApplicationBean> viewApplications(String ProgramName)
			throws AdmissionException {
		ArrayList<ApplicationBean> al3 = new ArrayList<>();
		try {
			conn = DBUtil.establishConnection();
			PreparedStatement pstmt = conn
					.prepareStatement(IQueryMapper.VIEW_APP2);
			pstmt.setString(1, ProgramName);

			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				
				int Application_Id= rs.getInt(1);
				String Full_name= rs.getString(2);
				Date Date_of_birth=rs.getDate(3);
				String Highest_qualification=rs.getString(4);
				int Marks_obtained=rs.getInt(5);
				String Goals=rs.getString(6);
				String Email_id=rs.getString(7);
				int Scheduled_program_id=rs.getInt(8);
				String Status=rs.getString(9);
				Date Date_of_Interview=rs.getDate(10);
				
				application5.setApplication_Id(Application_Id) ;
				application5.setFull_name(Full_name) ;
				application5.setDate_of_birth(Date_of_birth) ;
				application5.setHighest_qualification(Highest_qualification) ;
				application5.setMarks_obtained(Marks_obtained) ;
				application5.setGoals(Goals) ;
				application5.setEmail_id(Email_id) ;
				application5.setScheduled_program_id(Scheduled_program_id);
				application5.setStatus(Status) ;
				application5.setDate_of_Interview(Date_of_Interview) ;
				
         al3.add(application5);

						}

            } catch (SQLException e) {
						throw new AdmissionException(
								"Exception occured while viewing the list of  programs offered by the university : "
										+ e.getMessage());
					}

					return al3;
					
				}
				
	
	/*
	 * this method is used to Accept/Reject the applications on the details of
	 * applicant.
	 */
	@Override
	public ApplicationBean decidingApplicationStatus(ApplicationBean app4)
			throws AdmissionException {

		int marks = 0;
		String status2 = "";
		try {
			conn = DBUtil.establishConnection();

			PreparedStatement pstmt = conn
					.prepareStatement(IQueryMapper.VIEW_MARKS);
			pstmt.setInt(1, app4.getApplication_Id());
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				marks = rs.getInt(1);
			}
			if (marks >= 70) {
				status2 = "accepted";
			} else {
				status2 = "rejected";
			}
			app4.setStatus(status2);
			if (status2.equalsIgnoreCase("accepted")) {
				PreparedStatement pstmt1 = conn
						.prepareStatement(IQueryMapper.UPDATE_QUERY);
				pstmt1.setInt(1, app4.getApplication_Id());
				pstmt1.executeUpdate();
				PreparedStatement pstmt2 = conn
						.prepareStatement(IQueryMapper.VIEW_IDATE);
				ResultSet rs1 = pstmt2.executeQuery();
				while (rs1.next()) {
					app4.setDate_of_Interview(rs1.getDate(1));
				}
			} else if (status2.equalsIgnoreCase("rejected")) {
				System.out.println("Sorry! Your Application has been Rejected since your marks are less than 70");
			}
			PreparedStatement pstmt3 = conn.prepareStatement(IQueryMapper.UPDATE_STATUS);
			pstmt3.setString(1, status2);
			pstmt3.setInt(2, app4.getApplication_Id());
			pstmt3.executeUpdate();
		} catch (SQLException e) {

			throw new AdmissionException(
					"exception occured while updating status : "
							+ e.getMessage());

		}
		return app4;
	}

	/*
	 * This method is used to manage the programs offered by the University.
	 */
	@Override
	public int managingProgramsOffered(Programs_OfferedBean program1)
			throws AdmissionException {
		try {
			conn = DBUtil.establishConnection();

			PreparedStatement pstmt = conn
					.prepareStatement(IQueryMapper.INSERT_QUERY1);
			pstmt.setInt(1, program1.getScheduled_program_id());
			pstmt.setString(2, program1.getProgramName());
			pstmt.setString(3, program1.getDescription());
			pstmt.setString(4, program1.getApplicant_eligibility());
			pstmt.setInt(5, program1.getDuration());
			pstmt.setString(6, program1.getDegree_certificate_offered());
			
			n = pstmt.executeUpdate();
			System.out.println(n);
        
		} catch (SQLException e) {
			throw new AdmissionException(
					"problem occured while updating the information of programs offered : "
							+ e.getMessage());
		}
		return n;
		
		
	}
	@Override
	public int deleteProgramsOffered(String programName)
			throws AdmissionException {
		
		try {
			conn = DBUtil.establishConnection();

			PreparedStatement pstmt = conn.prepareStatement(IQueryMapper.UPDATE_QUERY1);
			pstmt.setString(1, programName);
			n = pstmt.executeUpdate();
			System.out.println(n);
        
		} catch (SQLException e) {
			throw new AdmissionException(
					"problem occured while updating the information of programs offered : "
							+ e.getMessage());
		}
		return n;
	}

	/*
	 * This method is used to manage the programs scheduled by the University.
	 */
	@Override
	public int managingScheduledPrograms(Programs_ScheduledBean program)
			throws AdmissionException {

		try {
			conn = DBUtil.establishConnection();
			
			PreparedStatement pstmt = conn.prepareStatement(IQueryMapper.INSERT_QUERY2);

			pstmt.setInt(1, program.getScheduled_program_id());
			pstmt.setString(2, program.getProgramName());
			pstmt.setString(3, program.getLocation());
			pstmt.setDate(4, program.getStart_date());
			pstmt.setDate(5, program.getEnd_date());
			pstmt.setInt(6, program.getSessions_per_week());
			n = pstmt.executeUpdate();
			System.out.println(n);
			
		} catch (SQLException e) {
			throw new AdmissionException(
					"problem occured while updating the schedules of programs offered : "
							+ e.getMessage());
		}
		return n;

	}
	@Override
	public int deleteScheduledPrograms(String programName)
			throws AdmissionException {
		try {
			conn = DBUtil.establishConnection();
			PreparedStatement pstmt1 = conn.prepareStatement(IQueryMapper.UPDATE_QUERY2);
			pstmt1.setString(1, programName);
			n = pstmt1.executeUpdate();
			System.out.println(n);
		
        
		} catch (SQLException e) {
			throw new AdmissionException(
					"problem occured while updating the schedules of programs offered : "
							+ e.getMessage());
		}
		return n;
	}


	
	/*
	 * To view the list of programs scheduled.
	 */
	@Override
	public ArrayList<Programs_ScheduledBean> viewListofProgramsScheduled(
			Date start_date, Date end_date) throws AdmissionException {
		ArrayList<Programs_ScheduledBean> al = new ArrayList<Programs_ScheduledBean>();
		try {
			conn = DBUtil.establishConnection();
			PreparedStatement pstmt = conn
					.prepareStatement(IQueryMapper.VIEW_SCHEDULE);
			pstmt.setDate(1, start_date);
			pstmt.setDate(2, end_date);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				Programs_ScheduledBean program = new Programs_ScheduledBean();

				int Scheduled_program_id = rs.getInt(1);
				String ProgramName = rs.getString(2);
				String Location = rs.getString(3);
				Date Start_date = rs.getDate(4);
				Date End_date = rs.getDate(5);
				int Sessions_per_week = rs.getInt(6);

				program.setScheduled_program_id(Scheduled_program_id);
				program.setProgramName(ProgramName);
				program.setLocation(Location);
				program.setStart_date(Start_date);
				program.setEnd_date(End_date);
				program.setSessions_per_week(Sessions_per_week);

				al.add(program);

			}

		} catch (SQLException e) {
			throw new AdmissionException(
					"Exception occured while viewing the list of programs scheduled : "
							+ e.getMessage());
		}

		return al;

	}
	/*
	 * To view the final  list of applicants selected after Interview.
	 */
	@Override
	public ApplicationBean updateinterviewStatus(int application_id)
			 {
		int marks = 0;
		String status = null;
		try {
			conn = DBUtil.establishConnection();
			PreparedStatement pstmt = conn.prepareStatement(IQueryMapper.VIEW_DETAILS1);
			pstmt.setInt(1, application_id);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				status = rs.getString(1);
				marks = rs.getInt(2);
			}
			if ("rejected".equalsIgnoreCase(status)) {
				System.out.println("Sorry!! Your application has already been Rejected.");
			} else {
				if (marks >= 85) {
					status = "confirmed";
				} else {
					status = "rejected";
				}
				application3.setStatus(status);
				if (status.equalsIgnoreCase("confirmed")) {
					PreparedStatement pstmt1 = conn.prepareStatement(IQueryMapper.VIEW_DETAILS);
					pstmt1.setInt(1, application_id);
					ResultSet rs1 = pstmt1.executeQuery();
					while (rs1.next()) {
						email_id = rs1.getString(1);
						schedule_id = rs1.getInt(2);
					}
					PreparedStatement pstmt2 = conn.prepareStatement(IQueryMapper.INSERT_QUERY3);
					pstmt2.setString(1, email_id);
					pstmt2.setInt(2, application_id);
					pstmt2.setInt(3, schedule_id);
					pstmt2.executeUpdate();
					
					System.out.println("The status of participants is successfully updated as "+status);
				}

				if (status.equalsIgnoreCase("rejected")) {
					System.out.println("Sorry! Your Application has been Rejected since your score is less than 85");
				}
				PreparedStatement pstmt3 = conn.prepareStatement(IQueryMapper.UPDATE_STATUS);
				pstmt3.setString(1, status);
				pstmt3.setInt(2, application_id);
				pstmt3.executeUpdate();
			}
		}

		catch (SQLException e) {

			System.out.println(e);

		}
		return application3;

	}
	/*
	 * To view the final updated status of applicants.
	 */
	@Override
	public ArrayList<ApplicationBean> viewListofApplicants(String  ProgramName) throws AdmissionException {
		ArrayList<ApplicationBean> al1 = new ArrayList<ApplicationBean>();
		try {
			conn = DBUtil.establishConnection();
			PreparedStatement pstmt = conn.prepareStatement(IQueryMapper.VIEW_APP2);
			pstmt.setString(1, ProgramName);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				ApplicationBean app5 = new ApplicationBean();

				
			int  Application_Id = rs.getInt(1);
			String	full_name = rs.getString(2);
			Date date_of_birth=rs.getDate(3);
			String highest_qualification=rs.getString(4);
			int marks_obtained=rs.getInt(5);
			String goals=rs.getString(6);
		    String email_id=rs.getString(7);
		    int scheduled_program_id1=rs.getInt(8);
		    String status=rs.getString(9);
			Date Date_of_Interview=rs.getDate(10);

				app5.setApplication_Id (Application_Id );
				app5.setFull_name(full_name);
				app5.setDate_of_birth(date_of_birth);
				app5.setHighest_qualification(highest_qualification);
				app5.setMarks_obtained(marks_obtained);
				app5.setGoals(goals);
				app5.setEmail_id(email_id);
				app5.setScheduled_program_id(scheduled_program_id1);
				app5.setStatus(status);
				app5.setDate_of_Interview(Date_of_Interview);

				al1.add(app5);

			}

		} catch (SQLException e) {
			throw new AdmissionException(
					"Exception occured while viewing the  final list of applicants  : "
							+ e.getMessage());
		}

		return al1;

	}
}

