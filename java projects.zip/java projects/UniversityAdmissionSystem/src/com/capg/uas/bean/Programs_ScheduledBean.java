package com.capg.uas.bean;

import java.sql.Date;

public class Programs_ScheduledBean {
	
//declaring all the data members as private inside the bean class
private int Scheduled_program_id;
private String ProgramName;
private String	Location; 
private Date start_date;
private Date end_date;
private int sessions_per_week;

//generating getters and setters
public int getScheduled_program_id() {
	return Scheduled_program_id;
}
public void setScheduled_program_id(int pgm_id) {
	this.Scheduled_program_id = pgm_id;
}
public String getProgramName() {
	return ProgramName;
}
public void setProgramName(String ProgramName) {
	this.ProgramName = ProgramName;
}
public String getLocation() {
	return Location;
}
public void setLocation(String location) {
	this.Location = location;
}
public Date getStart_date() {
	return start_date;
}
public void setStart_date(Date start_date) {
	this.start_date = start_date;
}
public Date getEnd_date() {
	return end_date;
}
public void setEnd_date(Date end_date) {
	this.end_date = end_date;
}
public int getSessions_per_week() {
	return sessions_per_week;
}
public void setSessions_per_week(int sessions_per_week) {
	this.sessions_per_week = sessions_per_week;
}

public Programs_ScheduledBean() {
	// TODO Auto-generated constructor stub
}
@Override
public String toString() {
	return "Programs_ScheduledBean [Scheduled_program_id="
			+ Scheduled_program_id + ", ProgramName=" + ProgramName
			+ ", Location=" + Location + ", start_date=" + start_date
			+ ", end_date=" + end_date + ", sessions_per_week="
			+ sessions_per_week + "]";
}



}
