package com.capg.uas.bean;

public class ParticipantsBean {
	
	//declaring all the data members as private inside the bean class
	private String Roll_no ;
	private String email_id ; 
    private int	Application_id;
	private String Scheduled_program_id ;
	
	//generating getters and setters
	public String getRoll_no() {
		return Roll_no;
	}
	public void setRoll_no(String roll_no) {
		this.Roll_no = roll_no;
	}
	public String getEmail_id() {
		return email_id;
	}
	public void setEmail_id(String email_id) {
		this.email_id = email_id;
	}
	public int getApplication_id() {
		return Application_id;
	}
	public void setApplication_id(int application_id) {
		Application_id = application_id;
	}
	public String getScheduled_program_id() {
		return Scheduled_program_id;
	}
	public void setScheduled_program_id(String scheduled_program_id) {
		Scheduled_program_id = scheduled_program_id;
	}
	
	public ParticipantsBean() {
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "ParticipantsBean [Roll_no=" + Roll_no + ", email_id="
				+ email_id + ", Application_id=" + Application_id
				+ ", Scheduled_program_id=" + Scheduled_program_id + "]";
	}


}
