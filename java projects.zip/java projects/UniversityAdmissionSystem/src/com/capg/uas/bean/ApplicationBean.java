package com.capg.uas.bean;

import java.util.Date;

public class ApplicationBean {
	//declaring all the data members as private inside the bean class
	
	private int Application_Id;
	private String full_name;
	private Date date_of_birth;
	private String highest_qualification;
	private int marks_obtained;
	private String goals;
	private String email_id;
	private int scheduled_program_id;
	private String status;
	private Date Date_of_Interview;
	
	public ApplicationBean(){
		
	}
	public ApplicationBean(String full_name, Date date_of_birth,
			String highest_qualification, int marks_obtained, String goals,
			String email_id, int scheduled_program_id) {
		super();
		this.full_name = full_name;
		this.date_of_birth = date_of_birth;
		this.highest_qualification = highest_qualification;
		this.marks_obtained = marks_obtained;
		this.goals = goals;
		this.email_id = email_id;
		this.scheduled_program_id = scheduled_program_id;
		
	}

	@Override
	//toString method
	public String toString() {
		return "ApplicationBean [Application_Id=" + Application_Id
				+ ", full_name=" + full_name + ", date_of_birth="
				+ date_of_birth + ", highest_qualification="
				+ highest_qualification + ", marks_obtained=" + marks_obtained
				+ ", goals=" + goals + ", email_id=" + email_id
				+ ", scheduled_program_id=" + scheduled_program_id
				+ ", status=" + status + ", Date_of_Interview="
				+ Date_of_Interview + "]";
	}
	
	//getters and setters
	public int getApplication_Id() {
		return Application_Id;
	}
	public void setApplication_Id(int application_Id) {
		this.
		
		Application_Id = application_Id;
	}
	public String getFull_name() {
		return full_name;
	}
	public void setFull_name(String full_name) {
		this.full_name = full_name;
	}
	public Date getDate_of_birth() {
		return date_of_birth;
	}
	public void setDate_of_birth(Date date_of_birth) {
		this.date_of_birth = date_of_birth;
	}
	public String getHighest_qualification() {
		return highest_qualification;
	}
	public void setHighest_qualification(String highest_qualification) {
		this.highest_qualification = highest_qualification;
	}
	public int getMarks_obtained() {
		return marks_obtained;
	}
	public void setMarks_obtained(int marks_obtained) {
		this.marks_obtained = marks_obtained;
	}
	public String getGoals() {
		return goals;
	}
	public void setGoals(String goals) {
		this.goals = goals;
	}
	public String getEmail_id() {
		return email_id;
	}
	public void setEmail_id(String email_id) {
		this.email_id = email_id;
	}
	public int getScheduled_program_id() {
		return scheduled_program_id;
	}
	public void setScheduled_program_id(int i) {
		this.scheduled_program_id = i;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Date getDate_of_Interview() {
		return Date_of_Interview;
	}
	public void setDate_of_Interview(Date date_of_Interview) {
		this.Date_of_Interview = date_of_Interview;
	}
	

}
