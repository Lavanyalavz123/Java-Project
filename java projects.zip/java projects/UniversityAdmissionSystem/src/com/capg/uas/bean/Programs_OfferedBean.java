package com.capg.uas.bean;

public class Programs_OfferedBean {
	
	//declaring all the data members as private inside the bean class
	private String ProgramName;
	private String description;
	private String	applicant_eligibility;
	private int	duration;
	private String	degree_certificate_offered;
	private int Scheduled_program_id;
	//generating getters and setters
	public String getProgramName() {
		return ProgramName;
	}
	public void setProgramName(String programName) {
		this.ProgramName = programName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getApplicant_eligibility() {
		return applicant_eligibility;
	}
	public void setApplicant_eligibility(String applicant_eligibility) {
		this.applicant_eligibility = applicant_eligibility;
	}
	public int getDuration() {
		return duration;
	}
	public void setDuration(int duration) {
		this.duration = duration;
	}
	public String getDegree_certificate_offered() {
		return degree_certificate_offered;
	}
	public void setDegree_certificate_offered(String degree_certificate_offered) {
		this.degree_certificate_offered = degree_certificate_offered;
	}
	
	public Programs_OfferedBean(){
		
	}
	@Override
	public String toString() {
		return "Programs_OfferedBean [ProgramName=" + ProgramName
				+ ", description=" + description + ", applicant_eligibility="
				+ applicant_eligibility + ", duration=" + duration
				+ ", degree_certificate_offered=" + degree_certificate_offered
				+ "]";
	}
	public int getScheduled_program_id() {
		return Scheduled_program_id;
	}
	public void setScheduled_program_id(int scheduled_program_id) {
		Scheduled_program_id = scheduled_program_id;
	}
	

}
