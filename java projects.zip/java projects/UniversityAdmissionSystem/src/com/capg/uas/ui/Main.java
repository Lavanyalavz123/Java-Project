
/* Projectname:UniversityAdmissionSystem
 * created by: Lavanya N
 * Emp ID:     155192
 * created on: 07/10/2018
 */

package com.capg.uas.ui;

import java.sql.Date;
import java.util.ArrayList;
import java.util.Scanner;

import org.apache.log4j.Logger;

import com.capg.uas.bean.ApplicationBean;
import com.capg.uas.bean.ParticipantsBean;
import com.capg.uas.bean.Programs_OfferedBean;
import com.capg.uas.bean.Programs_ScheduledBean;
import com.capg.uas.exception.AdmissionException;
import com.capg.uas.service.IMsgMapper;
import com.capg.uas.service.IUASService;
import com.capg.uas.service.UASServiceImpl;

public class Main {
    
	static Logger log = Logger.getRootLogger();
	public static void main(String[] args) throws AdmissionException {

		UASServiceImpl uasServ = new UASServiceImpl();
		ApplicationBean application = new ApplicationBean();
		Programs_OfferedBean program1 = new Programs_OfferedBean();
		Programs_ScheduledBean program = new Programs_ScheduledBean();
		ParticipantsBean participant = new ParticipantsBean();
		ApplicationBean application5 = new ApplicationBean();

		int type = 0, loop = 0, application_id,option3=0,option4=0;
		int n = 0;
		String option2;

		/*
		 * Menu to be displayed to the user
		 */
		System.out.println("*****Welcome to University Admission System*****");
    	
		
    	System.out.println("=======================================================");
		System.out.println("||1.Proceed as Applicant ||");
		System.out.println("||2.Proceed as  Members of Admission Committee (MAC)||");
		System.out.println("||3.Proceed as Administration||");
		System.out.println("||4. Exit  ||");
		System.out.println("========================================================");
		
		
		System.out.println("enter option :");
		Scanner scanner = new Scanner(System.in);
		Scanner scanner1 = new Scanner(System.in);
		int option = scanner.nextInt();

		switch (option) {

		case 1:
			System.out
					.println("1.View all programs scheduled\n2.Apply for scheduled program\n3.View application status");
			int option1 = scanner.nextInt();
			switch (option1) {
			case 1:/********************************************************************
				 * 
				 * 
				 *To view all the programs scheduled by the University
				 * 
				 *******************************************************************/
				
				ArrayList<Programs_ScheduledBean> al2 = new ArrayList<Programs_ScheduledBean>();

				try {
					al2 = uasServ.viewAllPrograms();
					if(al2.isEmpty()){
						log.error("No records found!!");
					}
					else {
						log.info("Records Displayed Successfully!!");
						System.out.println("Records are displayed successfully!!"); 
					}

					for (Programs_ScheduledBean p : al2) {
						System.out.println("Scheduled_program_id:" +p.getScheduled_program_id());
						System.out.println("programName:"+p.getProgramName());
						System.out.println("Location:"+p.getLocation());
						System.out.println("Start_date:"+p.getStart_date());
						System.out.println("End_date:"+p.getEnd_date());
						System.out.println("Sessions_per_week:"+p.getSessions_per_week());
						
						System.out.println();
						
					} 
						
				}

				catch (AdmissionException e) {
					System.err.println("exception: "+e.getMessage());
				}

				break;
	
			case 2:

				IUASService service = new UASServiceImpl();
				/********************************************************************
				 * 
				 * 
				 * Filling the Applicant details for registering 
				 * 
				 *******************************************************************/

				System.out.println("Enter Full_name ");
				String name = scanner.next();
				while (!uasServ.isValidName(name)) {
					System.err.println(IMsgMapper.NAME_ERROR);
					name = scanner1.nextLine();
				}
				
				
				System.out.println("Enter date_of_birth in the format yyyy-mm-dd ");
				String dob = scanner.next();
				
				while (!uasServ.isValidDate(dob)) {
					System.err.println(IMsgMapper.NAME_ERROR1);
					name = scanner1.nextLine();
				}
				Date birth = Date.valueOf(dob);
				String dateString=birth.toString();
				
				System.out.println("Enter highest_qualification ");
				String qualification = scanner.next();
				while (!uasServ.isValidqualification(qualification)) {
					System.err.println(IMsgMapper.NAME_ERROR10);
					qualification = scanner1.nextLine();
				}
				
				System.out.println("Enter marks_obtained");
				String marksStr = scanner.next();
				
				while (!uasServ.isvalidmarks(marksStr)) {
					System.err.println(IMsgMapper.NAME_ERROR2);
					marksStr = scanner.next();
				}  
				int marks=Integer.parseInt(marksStr);
				
				System.out.println("Enter Goals");
				String goals = scanner.next();
				while (!uasServ.isValidName(goals)) {
					System.err.println(IMsgMapper.NAME_ERROR3);
					goals = scanner.next();
				} 
				
				System.out.println("Enter email_id");
				String email_id = scanner1.nextLine();
				while (!uasServ.isValidMail(email_id)) {
					System.err.println(IMsgMapper.NAME_ERROR4);
					email_id = scanner1.nextLine();
				}
				
				System.out.println("Existing ScheduleProgram_ids Are:-[1000,1001,1002,1003,1004,1005,1006]");	
				System.out.println(" Please Enter ScheduleProgram_id  from above list:");
				
             String SidStr = scanner.next();
				
				while (!uasServ.isvalidSid(SidStr)) {
					System.err.println(IMsgMapper.NAME_ERROR12);
					SidStr = scanner.next();
				}  
				int ScheduleProgram_id =Integer.parseInt(SidStr);
				 
            	application.setFull_name(name);
				application.setDate_of_birth(birth);
				application.setHighest_qualification(qualification);
				application.setMarks_obtained(marks);
				application.setGoals(goals);
				application.setEmail_id(email_id);
				application.setScheduled_program_id(ScheduleProgram_id);
				

				try {
					n=service.applyForScheduledProgram(application);
					if(n==1)
					{
						log.info("Registration Successful!!");
					System.out.println("You have Successfully Applied and your application id is "
									+ application.getApplication_Id());
				}
					else{
						
						log.error("Registration Unsuccessful!!");
					}
				}catch (AdmissionException e) {
					System.err.println("exception: "+e.getMessage());
				}
				break;

			case 3:
				/********************************************************************
				 * 
				 * 
				 * To view the status of application
				 * 
				 *******************************************************************/
				IUASService service1 = new UASServiceImpl();
				System.out.println("Enter your Application_Id ");
				int id = scanner.nextInt();
				try {
					String status1 = service1.viewApplicationStatus(id);
					if (status1 != null) {
						log.info("Status is displayed Successfully!!");
						System.out.println("Your application is accepted");
					} else {
						log.error("Viewing status is Unsuccessful!!");
						System.out.println("Your application is rejected");
					}
				} catch (AdmissionException e) {
					System.err.println("exception: "+e.getMessage());
				}
				break;
			}	
				
			break;
		case 2:
			/********************************************************************
			 * 
			 * 
			 * Checking the Login credentials for MAC
			 * 
			 *******************************************************************/
			while (loop == 0) {
				System.out.println("Enter Loginid");
				String login_id = scanner.next();
				System.out.println("Enter Password");
				String password = scanner.next();
				try {
					type = uasServ.checkLogin(login_id, password);
					loop = 1;
					if (type == 3) {
						loop = 0;
						log.error("Login UnSuccessful!!");
						}
					else {
						log.info("Login Successful!!");
					}
				} catch (AdmissionException e) {
					System.err.println("exception: "+e.getMessage());
				}
			}
	
			
			System.out.println("****************************************");
			System.out.println("1. View Applications for Specific Program");
			System.out.println("2. accept or reject Application");
			System.out.println("3. Update the status of Application after interview ");
			System.out.println("4. Exit");
			option = scanner.nextInt();
			switch (option) {
			case 1:
				/********************************************************************
				 * 
				 * 
				 * To view the applications for specific program.
				 * 
				 * 
				 *******************************************************************/
				System.out.println("Enter ProgramName");
				String pgmName = scanner.next();
				ArrayList<ApplicationBean> al3 = new ArrayList<ApplicationBean>();

				program.setProgramName(pgmName);
				try {
					al3 = uasServ.viewListofApplicants(pgmName);

					if(al3.isEmpty()){
						log.error("No records found!!");
					}
					else {
						log.info("Records Displayed Successfully!!");
						 
					}

					for (ApplicationBean p : al3) {
						System.out.println("ApplicationID:"+p.getApplication_Id());
						System.out.println("Name:"+p.getFull_name());
						System.out.println("DOB:"+p.getDate_of_birth());
						System.out.println("Qualification:"+p.getHighest_qualification());
						System.out.println("Marks_Obtained:"+p.getMarks_obtained());
						System.out.println("Goals:"+p.getGoals());
						System.out.println("Mail_ID:"+p.getEmail_id());
						System.out.println("Program_ID:"+p.getScheduled_program_id());
						System.out.println("Status:"+p.getStatus());
						System.out.println("DOI:"+p.getDate_of_Interview());
						System.out.println();

					} 
		
				}catch (AdmissionException e) {
		System.err.println("exception: "+e.getMessage());
				}

				break;
				
		
			case 2:
				/********************************************************************
				 * 
				 * 
				 * To accept/reject the applications based on the details of
				 * applicant.
				 * 
				 * 
				 *******************************************************************/

				ApplicationBean app4 = new ApplicationBean();
				System.out.println("Enter the Application_id");
				int app_id = scanner.nextInt();
				app4.setApplication_Id(app_id);
				try {
					application = uasServ.decidingApplicationStatus(app4);
					System.out.println("Status : " + app4.getStatus());
					System.out.println("DateofInterview : "
							+ app4.getDate_of_Interview());

				} catch (AdmissionException e) {
					System.out.println(e);
				}

				break;
				

			case 3:/********************************************************************
				 * 
				 * 
				 * To Update the interview status based on the details of
				 * applicant.
				 * 
				 * 
				 *******************************************************************/
				System.out.println("Enter the Application Id");

				try {
					application_id = scanner.nextInt();
					application = uasServ.updateinterviewStatus(application_id);
					
					if(n == 1){
						log.info("Updated Successfully!!");
					
					}
					else {
						log.error("Updation Unsuccessful!!");
					}
							
				} catch (AdmissionException e) {
					System.err.println("exception: "+e.getMessage());
				}
				break;

			case 4:
				System.out.println("Exiting...");
				System.exit(0);
			default:
				System.out.println("Wrong option entered");
				break;
			}
			break;

		case 3:
			/********************************************************************
			 * 
			 * 
			 * Checking the login credentials for Administration
			 * 
			 * 
			 * 
			 *******************************************************************/
			while (loop == 0) {
				System.out.println("Enter Loginid");
				String login_id1 = scanner.next();
				System.out.println("Enter Password");
				String password1 = scanner.next();
				try {
					type = uasServ.checkLogin(login_id1, password1);
					loop = 1;
					if (type == 3) {
						loop = 0;
						log.error("Login UnSuccessful!!");
					}
				else {
					log.info("Login Successful!!");
				}
			} catch (AdmissionException e) {
				System.err.println("exception: "+e.getMessage());
			}
		}
				

			System.out.println("****************************************");
			System.out.println("1. Update and Manage information of Programs Offered");
			System.out.println("2. Update and Manage information of Programs Scheduled");
			System.out.println("3. Generating the Report to view the list of final status of applicants");
			System.out.println("4. Generating the Report to view the list of programs scheduled in a given time");
			
			option = scanner.nextInt();
			switch (option) {
			case 1:
				/********************************************************************
				 * 
				 * 
				 * To update & manage the information of programs offered by the
				 * university.
				 * 
				 * 
				 *******************************************************************/
				
				System.out.println("*******************************************");
				System.out.println("1. Add Information of the programs offered");
				System.out.println("2. Delete Information of the programs offered");
				option3 = scanner.nextInt();
				switch(option3){
				
			case 1:
				System.out.println("Enter  Scheduled_program_id");
				int pgm_id = scanner.nextInt();
				
				System.out.println("Enter ProgramName ");
				String name = scanner.next();
				while (!uasServ.isValidName(name)) {
					System.err.println(IMsgMapper.NAME_ERROR);
					name = scanner.nextLine();
				}
				
				System.out.println("Enter description ");
				String descp = scanner.next();
				while (!uasServ.isValidDescp(descp)) {
					System.err.println(IMsgMapper.NAME_ERROR5);
					descp = scanner.nextLine();
				}
				
				System.out.println("Enter applicant_eligibility ");
				String eligibility = scanner.next();
				while (!uasServ.isValidEligibility(eligibility)) {
					System.err.println(IMsgMapper.NAME_ERROR6);
					name = scanner.nextLine();
				}
				
				System.out.println("Enter duration");
				int duration = scanner.nextInt();
				String durationString=Integer.toString(duration);
				while (!uasServ.isValidDuration(durationString)) {
					System.err.println(IMsgMapper.NAME_ERROR7);
					duration = scanner.nextInt();
				}
				
				
				System.out.println("Enter degree_certificate_offered");
				String certificate = scanner.next();
				

				program1.setProgramName(name);
				program1.setDescription(descp);
				program1.setApplicant_eligibility(eligibility);
				program1.setDuration(duration);
				program1.setDegree_certificate_offered(certificate);
				program1.setScheduled_program_id(pgm_id);

				try {
					n = uasServ.managingProgramsOffered(program1);
					if(n == 1){
						log.info("Updation Successful!!");
						System.out.println(n + "rows updated");
						System.out.println("Information regarding the programs offered is updated successfully ");
					}
					else {
						log.error("Updation Unsuccessful!!");
					}
				} catch (AdmissionException e) {
					System.err.println("exception: "+e.getMessage());
				}
			break;	
			
			case 2:
				System.out.println("Enter ProgramName ");
			     String name1 = scanner.next();
			     while (!uasServ.isValidName(name1)) {
						System.err.println(IMsgMapper.NAME_ERROR);
						name1 = scanner.nextLine();
					}
				
			 program1.setProgramName(name1);
				
			 try {
					n = uasServ.deleteProgramsOffered(name1);
					if(n == 1){
						log.info("Updation Successful!!");
						System.out.println(n + "rows updated");
						System.out.println("Information regarding the programs offered is updated successfully ");
					}
					else {
						log.error("Updation Unsuccessful!!");
					}
				} catch (AdmissionException e) {
					System.err.println("exception: "+e.getMessage());
				}
							
				break;
				}
				break;

			case 2:
				/********************************************************************
				 * 
				 * 
				 * To Manage the schedules of programs offered by the
				 * university.
				 * 
				 * 
				 *******************************************************************/
       
				System.out.println("****************************************");
				System.out.println("1. Add Information of the programs scheduled");
				System.out.println("2. Delete Information of the programs  scheduled");
				option4 = scanner.nextInt();
				switch(option4){
				case 1:
					
				System.out.println("Enter Scheduled_program_id ");
				int id = scanner.nextInt();
				
				System.out.println("Enter  ProgramName ");
				String Pname = scanner.next();
				while (!uasServ.isValidName(Pname)) {
					System.err.println(IMsgMapper.NAME_ERROR);
					Pname = scanner.nextLine();
				} 
				System.out.println("Enter Location ");
				String location = scanner.next();
				while (!uasServ.isValidLocation(location)) {
					System.err.println(IMsgMapper.NAME_ERROR9);
					location = scanner.nextLine();
				} 
				
				System.out.println("Enter start_date");
				String sdate = scanner.next();
				Date date1 = Date.valueOf(sdate);
				System.out.println("Enter end_date");
				String edate = scanner.next();
				Date date2 = Date.valueOf(edate);
				
				System.out.println("Enter sessions_per_week");
				int sessions = scanner.nextInt();
				String sessionsString=Integer.toString(sessions);
				while (!uasServ.isValidSession(sessionsString)) {
					System.err.println(IMsgMapper.NAME_ERROR7);
					sessions = scanner.nextInt();
				}
				
				program.setScheduled_program_id(id);
				program.setProgramName(Pname);
				program.setLocation(location);
				program.setStart_date(date1);
				program.setEnd_date(date2);
				program.setSessions_per_week(sessions);

				try {
					n = uasServ.managingScheduledPrograms(program);
					
					System.out.println(n + "rows updated");
					System.out.println("Information regarding the schedules of programs is updated successfully ");
				} catch (AdmissionException e) {
					System.out.println(e);
				}

				break;	
				
				case 2:
					System.out.println("Enter ProgramName ");
				    String name1 = scanner.next();
					
				 program.setProgramName(name1);
					
				 try {
						n = uasServ.deleteScheduledPrograms(name1);
						
						if(n == 1){
							log.info("Updation Successful!!");
							System.out.println(n + "rows updated");
							System.out.println("Information regarding the programs scheduled is updated successfully ");
						}
						else {
							log.error("Updation Unsuccessful!!");
						}
					} catch (AdmissionException e) {
						System.err.println("exception: "+e.getMessage());
					}
					break;
				}
			
			case 3:
				/********************************************************************
				 * 
				 * 
				 * To generate reports to view the final list of applicants who has been selected/accepted/rejected
				 * 
				 * 
				 * 
				 *******************************************************************/
				System.out.println("Enter ProgramName");
				String pgm_name = scanner.next();
				ArrayList<ApplicationBean> al1 = new ArrayList<ApplicationBean>();

				program.setProgramName(pgm_name);
				try {
					al1 = uasServ.viewListofApplicants(pgm_name);

					for (ApplicationBean p : al1) {
						System.out.println("ApplicationID:"+p.getApplication_Id());
						System.out.println("Name:"+p.getFull_name());
						System.out.println("DOB:"+p.getDate_of_birth());
						System.out.println("Qualification:"+p.getHighest_qualification());
						System.out.println("Marks_Obtained:"+p.getMarks_obtained());
						System.out.println("Goals:"+p.getGoals());
						System.out.println("Mail_ID:"+p.getEmail_id());
						System.out.println("Program_ID:"+p.getScheduled_program_id());
						System.out.println("Status:"+p.getStatus());
						System.out.println("DOI:"+p.getDate_of_Interview());
						System.out.println();
						
						if(al1.isEmpty()){
							log.error("No records found!!");
						}
						else {
							log.info("Records Displayed Successfully!!");
							//System.out.println("Records are displayed successfully!!"); 
						}

					}

				}  catch (AdmissionException e) {
					System.err.println("exception: "+e.getMessage());
				}

				break;

			case 4:
				/********************************************************************
				 * 
				 * 
				 * Generating report to view the list of programs scheduled.
				 * 
				 * 
				 *******************************************************************/

				System.out.println("Enter start_date");
				String sdate1 = scanner.next();
				Date date11 = Date.valueOf(sdate1);
				System.out.println("Enter end_date");
				String edate1 = scanner.next();
				Date date22 = Date.valueOf(edate1);
				ArrayList<Programs_ScheduledBean> al = new ArrayList<Programs_ScheduledBean>();

				program.setStart_date(date11);
				program.setEnd_date(date22);

				try {
					al = uasServ.viewListofProgramsScheduled(date11, date22);
					if(al.isEmpty()){
						log.error("No records found!!");
						System.out.println(" No program is scheduled in this duration!!");
					}
					else {
						log.info("Records Displayed Successfully!!");
						System.out.println("Records are displayed successfully!!"); 
					}

					for (Programs_ScheduledBean p : al) {
						System.out.println("Program_ID:"+p.getScheduled_program_id());
						System.out.println("ProgramName:"+p.getProgramName());
						System.out.println("Location:"+p.getLocation());
						System.out.println("StartDate:"+p.getStart_date());
						System.out.println("EndDate:"+p.getEnd_date());
						System.out.println("Sessions_per_Week:"+p.getSessions_per_week());
						System.out.println();
						
						
					}

				}  catch (AdmissionException e) {
					System.err.println("exception: "+e.getMessage());
				}

			break;
			}
			break;
		
			case 4:
				System.out.println("Exiting...");
				System.exit(0);
			default:
				System.out.println("Wrong option entered");
				break;
			}

			scanner.close();
		}
	}
