package com.capg.uas.test;

import static org.junit.Assert.*;

import java.sql.Date;

import org.junit.Test;

import com.capg.uas.bean.ApplicationBean;
import com.capg.uas.bean.UsersBean;
import com.capg.uas.dao.IUASdao;
import com.capg.uas.dao.UASdaoImpl;
import com.capg.uas.exception.AdmissionException;

public class TestDemo {

	IUASdao Uasdao=null;
	UsersBean user= null;
	ApplicationBean application=null;
	
	@Test
	public void TestcheckLogin()
			throws AdmissionException {
		Uasdao = new UASdaoImpl();
		assertEquals(1, Uasdao.checkLogin("lavu","dragon4777"));
	}
	
	@Test
	public void TestcheckLogin1() throws  AdmissionException {
		Uasdao = new UASdaoImpl();
		assertEquals(2, Uasdao.checkLogin("layn","dragon47"));
	}
	
	@Test
	public void TestapplyForProgram() throws  AdmissionException {
		Uasdao = new UASdaoImpl();
		ApplicationBean application= new ApplicationBean("Anil",Date.valueOf("1996-09-09"),"BE",85,"Developer","anil@gmail.com",1000);
		assertEquals(1,Uasdao.applyForScheduledProgram(application));
	}	

	

}
